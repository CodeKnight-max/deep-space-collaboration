import { ChainId } from '@deepspace-game/sdk'

export const MigrationSupported = [ChainId.BSC]
