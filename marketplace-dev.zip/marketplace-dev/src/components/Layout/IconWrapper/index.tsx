import styled from "styled-components";
import React from "react";
import Image from "next/image";

interface IconWrapperProps {
  icon: string
  className: string
  size?: number | string
  width?: number | string
  height?: number | string
}

export default function IconWrapper(props: IconWrapperProps): JSX.Element {
  return (
    <Style className={`flex items-center justify-center ${props.className}`}>
      <Image src={props.icon} width={props.size ?? props.width}
             height={props.size ?? props.height}/>
    </Style>
  )
}

const Style = styled.table`
  background-image: url("/images/ui/icon_box.svg");
  background-repeat: no-repeat;
  background-size: 100% 100%;
`
