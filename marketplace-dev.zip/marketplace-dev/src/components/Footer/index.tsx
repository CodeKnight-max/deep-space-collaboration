import React, { useEffect, useState } from 'react'
import Polling from '../Polling'
import styled from 'styled-components'
import axios from 'axios'
import { SERVICE_API_URL } from '../../constants'
import config from '../../config'
import cookie from 'cookie-cutter'
import CookiePolicyModal from "../Modal/CookiePolicyModal";
import PrivacyPolicyModal from "../Modal/PrivacyPolicyModal";
import TermsModal from "../Modal/TermsModal";
import CookieBanner, { CookieSelection } from "./CookieBanner";
import { BsArrowBarDown, BsArrowBarUp } from 'react-icons/bs'
import dayjs from 'dayjs';

interface FooterProps {
  isAtBottom?: boolean
  scrollToBottom?: () => void
  scrollToTop?: () => void
}

export default function Footer(props: FooterProps): JSX.Element {
  const [serverStatus, setServerStatus] = useState('')
  const [cookiePreference, setCookiePreference] = useState<CookieSelection | null>(
    JSON.parse(cookie.get('cookiePreference') ?? null)
  )
  const [showCookiePolicyModal, setShowCookiePolicyModal] = useState(false)
  const [showPrivacyPolicyModal, setShowPrivacyPolicyModal] = useState(false)
  const [showTermsModal, setShowTermsModal] = useState(false)

  useEffect(() => {
    checkService();
  }, [])

  const checkService = () => {
    axios.get(SERVICE_API_URL).then(resp => {
      const server_list = resp?.data?.servers_list
      if (server_list.length > 0) {
        server_list.map((item) => {
          if (config.ENVIRONMENT === item.server_environment.toUpperCase()) {
            setServerStatus(item.global_server_status)
          }
        })
      }
    });
  }

  const setCookieSelection = (selection: CookieSelection) => {
    setCookiePreference(selection)
    cookie.set('cookiePreference', JSON.stringify(selection), {
      expires: dayjs.utc().add(1, 'year').toDate(),
      path: '/'
    })
  }

  const showModal = (modal: 'cookie-policy' | 'privacy-policy' | 'terms') => {
    setShowCookiePolicyModal(false)
    setShowPrivacyPolicyModal(false)
    setShowTermsModal(false)

    switch (modal) {
      case 'cookie-policy':
        setShowCookiePolicyModal(true)
        break
      case 'privacy-policy':
        setShowPrivacyPolicyModal(true)
        break
      case 'terms':
        setShowTermsModal(true)
    }

    props.scrollToTop()
  }

  return (
    <Style>
      <footer className="bottom-0 right-0 mx-auto footer flex flex-col">
        {!cookiePreference &&
            <CookieBanner onCookiePolicyClick={() => setShowCookiePolicyModal(true)}
                          onAccept={setCookieSelection}/>
        }
        <div className="footer-border w-full"/>
        <div className="flex px-8 mb-1 h-10 justify-between items-center">
          <div className="flex">
            <div className='service_status goldman-font'>
              <span>Game Status: {serverStatus} </span>
            </div>
            <Polling/>
          </div>
          <div className="scroll-to-bottom">
            {props.isAtBottom && <BsArrowBarUp size="21px" onClick={props.scrollToTop}/>}
            {!props.isAtBottom && <BsArrowBarDown size="21px" onClick={props.scrollToBottom}/>}
          </div>
        </div>

        <div className="flex px-8 text-sm legal-links">
            <a href="#" onClick={() => showModal('cookie-policy')}>Cookie Policy</a>
            <a href="#" onClick={() => showModal('privacy-policy')}>Privacy Policy</a>
            <a href="#" onClick={() => showModal('terms')}>Terms & Conditions</a>
        </div>
      </footer>
      <CookiePolicyModal show={showCookiePolicyModal} onClose={() => {
        setShowCookiePolicyModal(false)
      }}/>
      <PrivacyPolicyModal show={showPrivacyPolicyModal} onClose={() => {
        setShowPrivacyPolicyModal(false)
      }}/>
      <TermsModal show={showTermsModal} onClose={() => {
        setShowTermsModal(false)
      }}/>
    </Style>

  )
}

const Style = styled.div`
  position: relative;
  top: -2.5rem;
  flex: 1 0 auto;
  border-top: 2.5rem solid rgba(13, 11, 16, 0.9);
  height: 0;

  .footer {
    position: relative;
    top: -2.5rem;

    .footer-border {
      border-bottom: 1px solid rgba(127, 22, 211, 0.4);
    }
  }

  .service_status, .scroll-to-bottom {
    color: rgb(75, 255, 255);

    &.service_status {
      text-transform: capitalize;
      margin-right: 1rem;
    }
    
    &.scroll-to-bottom {
      display: flex;
      align-items: center;
      height: 100%;
      cursor: pointer
    }
  }

  a {
    color: rgb(107, 114, 128);
    transition: color 100ms;
  }

  a:hover {
    color: rgb(227, 227, 227);
  }
  
  .legal-links a {
    margin-right: .5rem;
    
    &:last-child {
      margin-right: 0;
    }
  }
`
