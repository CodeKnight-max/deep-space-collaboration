import styled from "styled-components";
import { useEffect, useRef, useState } from "react";
import getBreakpoints from "../../services/responsive";


const Style = styled.div`
  position: absolute;
  z-index: 50;
  width: 100%;
  background-color: #202231;
  color: #fff;
  border-top: 1px solid rgba(127, 22, 211, 0.4);
  padding: 1rem 0;
  
  &.handset {
    padding: 1rem 2.5rem;
    
    .desc {
      margin: auto;
      width: auto;
      max-width: none;
      
      p:first-child {
        margin-bottom: 1rem;
      }
    }
    
    label {
      margin-right: 1rem;
    }
  }

  .desc {
    margin: 0 auto 1.5rem;
    width: 750px;
    max-width: 80%;
  }

  a {
    cursor: pointer;

    &:hover {
      color: #9858B2 !important;
    }
  }

  label {
    display: flex;
    align-items: center;
    margin-right: 5rem;

    input {
      margin-right: .5rem;
    }
  }

  button {
    width: 150px;
    height: 40px;
    border: 1px solid #650AAE;
    color: #9858B2;
    border-radius: 5px;

    &.primary {
      background-color: #650AAE;
      border-color: transparent;
      color: #fff;
    }

    &:first-child {
      margin-right: 3rem;
    }

    &:hover {
      background-color: #650AAE;
      color: #fff;
      border-color: #fff;
    }
  }
`

interface CookieBannerProps {
  onCookiePolicyClick: () => void
  onAccept: (selection: CookieSelection) => void
}

export interface CookieSelection {
  necessary: boolean
  preferences: boolean
  statistics: boolean
}

export default function CookieBanner(props: CookieBannerProps): JSX.Element {
  const [height, setHeight] = useState(0)
  const ref = useRef(null)
  const breakpoints = getBreakpoints()

  const selection: CookieSelection = {
    necessary: true,
    preferences: false,
    statistics: false
  }

  useEffect(() => {
    setHeight(ref.current.clientHeight + 1)
  })

  const acceptSelection = () => {
    props.onAccept(selection)
  }

  const acceptAll = () => {
    props.onAccept({ necessary: true, preferences: true, statistics: true })
  }

  return (
    <Style ref={ref} style={{ top: `-${height}px` }} className={breakpoints.lg ? '' : 'handset px-5'}>
      <div className="desc">
        <p>
          We use cookies to provide you with the best experience and to help improve our application.
        </p>
        <p>
          Please read our <a onClick={props.onCookiePolicyClick} className="transition-all">Cookie Policy</a> for more
          information. By clicking "Accept all", you agree to the storing of cookies on your device to enhance site
          navigation, analyze site usage and provide customer support.
        </p>
      </div>

      <div className={`${breakpoints.lg ? 'flex' : 'flex flex-col'} justify-center items-center`}>
        <div className="flex flex-wrap py-3">
          <label>
            <input type="checkbox" checked disabled/> Necessary
          </label>
          <label>
            <input type="checkbox" onChange={(e) => selection.preferences = e.target.checked}/> Preferences
          </label>
          <label>
            <input type="checkbox" onChange={(e) => selection.statistics = e.target.checked}/> Statistics
          </label>
        </div>

        <div className={`${breakpoints.lg ? '' : 'flex justify-around'}`}>
          <button className="transition-all" onClick={acceptSelection}>Accept selection</button>
          <button className="primary transition-all" onClick={acceptAll}>Accept all</button>
        </div>
      </div>
    </Style>
  )
}