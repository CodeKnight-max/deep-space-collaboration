import { X } from 'react-feather'

const CloseIcon = (props) => <X className="cursor-pointer" {...props} />

export default CloseIcon
