import React, { useEffect, useState } from 'react'
import ReactDOM from 'react-dom'
import styled from 'styled-components'
import cn from 'classnames'
import { AiFillCloseCircle } from 'react-icons/ai'
import { detectBrowser, getShipTypeById, getTextureTypeById } from '../../functions/deepspace'
import config from "../../config";
import nProgress from "nprogress";

const StyledCard = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100vw;
  height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  right: auto;
  bottom: auto;
  margin-right: -50%;
  backdrop-filter:blur(12px);
  -webkit-backdrop-filter:blur(12px);
  
  .body {
    justify-content: center;
    width: auto;
    background-repeat: no-repeat;
    background-size: 100% 100%;
  }
  .browser-1{
    background-image:url("/images/ui/modals/modal-6.png");
  }
  .browser-2{
    background-image:url("/images/ui/modals/modal_1.png");
  }
`

interface ShipReviewModalProps {
  show?: boolean
  nftData?: any
  onClose?: () => void
}

export default function ShipReviewModal({ show, nftData, onClose }: ShipReviewModalProps) {
  const baseUrl = `${config.VIEWER_URL}?assetType=ships`
  const [isBrowser, setIsBrowser] = useState(false)
  const [isIframeLoaded, setIframeLoaded] = useState(false)
  const [shipType, setShipType] = useState(null)
  const [textureType, setTextureType] = useState(null)
  const [textureNum, setTextureNum] = useState(null)
  const browserType = detectBrowser();
  useEffect(() => {
    setIsBrowser(true)
  }, [])

  useEffect(() => {
    if (show) {
      nProgress.start()
      setShipType(getShipTypeById(nftData.shipType))
      setTextureType(getTextureTypeById(nftData.textureType))
      setTextureNum(nftData.textureNum)
    }
  }, [show, nftData])

  const iframeLoaded = () => {
    nProgress.done()
    setIframeLoaded(true)
  }

  const close = () => {
    onClose()
    setIframeLoaded(false)
  }

  const modalContent = show && shipType && textureType && textureNum ? (
    <StyledCard className="z-50 Modal cursor-pointer" style={{display: isIframeLoaded ? 'flex' : 'none'}} onClick={close}>
      <div className={cn('sm:flex sm:flex-row body text-black items-center mx-2 p-5 relative', {
        'browser-1': browserType !== 'Firefox',
        'browser-2': browserType === 'Firefox',
      })}>
        <div className="absolute top-7 right-7">
          <AiFillCloseCircle onClick={close} style={{ cursor: 'pointer', color: 'white', fontSize: "28px" }} />
        </div>
        <iframe onLoad={iframeLoaded}
                src={`${baseUrl}&shipType=${shipType}&textureType=${textureType}&textureNum=${textureNum}&noBg=1`}
                style={{minHeight: "500px", width:"600px", maxWidth: "100%"}}></iframe>
      </div>
    </StyledCard >
  ) : null
  if (!isBrowser) {
    return null
  } else {
    return ReactDOM.createPortal(modalContent, document.getElementById('modal-root'))
  }

}
