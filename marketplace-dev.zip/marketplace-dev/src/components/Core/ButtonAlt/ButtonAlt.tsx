import React, { ForwardedRef } from "react";
import styled from "styled-components";
import Image from "next/image";
import getBreakpoints from "../../../services/responsive";

interface ButtonAltProps {
  text?: string
  icon?: any
  active?: boolean
  link?: boolean
  primary?: boolean
  secondary?: boolean
  accent?: boolean
  onClick?: () => void
  href?: string
  className?: string
}

const ButtonAlt = React.forwardRef((props: ButtonAltProps, ref: ForwardedRef<any>) => {
  const breakpoints = getBreakpoints();

  const classNames = (): string => {
    let result = []
    if (props.active) result.push('active')
    if (props.link) result.push('link')
    if (props.primary) result.push('primary')
    if (props.secondary) result.push('secondary')
    if (props.accent) result.push('accent')
    if (!!props.icon && !props.text) result.push('btn-icon')
    return `${result.join(' ')} ${props.className}`
  }

  return (
    <Style className={classNames()} onClick={props.onClick} ref={ref} href={props.href}>
      { !props.icon && !!props.text &&
          <>{ props.text }</>
      }
      {!!props.icon && typeof props.icon === 'object' &&
          <Image src={props.icon}
                 width={breakpoints.lg || !props.text ? '20px' : '15px'}
                 height={breakpoints.lg || !props.text ? '20px' : '15px'}/>}
      {!!props.icon && typeof props.icon === 'function' && props.icon()}
      { !!props.icon && !!props.text &&
          <span style={{ marginLeft: '.7rem' }}>{ props.text }</span>}
    </Style>
  )
})

const Style = styled.a`
  display: flex;
  align-items: center;
  justify-content: center;
  padding: .5rem 1rem;
  text-shadow: none;
  transition: all 100ms;
  color: #fff;

  &:hover, &.active {
    cursor: pointer;
  }

  &.btn-icon {
    padding: .5rem .7rem;
  }

  &.primary {
    background-image: url("/images/ui/btn.svg");
    background-repeat: no-repeat;
    background-size: 100% 100%;
    min-width: 80px;

    &:hover, &.active {
      background-image: url("/images/ui/btn_active.svg");
    }
  }

  &.accent, &.secondary {
    background-color: #A2DBF41A;
    border-radius: 0.25rem;
    border: 1px solid transparent;

    &:hover, &.accent.active {
      background-color: #00AEEF66;
    }
    
    &.secondary.active {
      border-color: #00AEEF66;
    }
  }

  &.accent {
    border: 1px solid #a2dbf4;
  }

  &.link {
    padding: 0;
    color: #00aeef;

    &:hover {
      color: #a2dbf4;
    }
  }
`

export default ButtonAlt