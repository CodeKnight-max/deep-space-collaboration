import React from "react";
import styled from "styled-components";

export default function Divider(): JSX.Element {
  return (
    <Style />
  )
}

const Style = styled.div`
  background-image: url("/images/ui/divider.svg");
  background-repeat: no-repeat;
  background-size: 100% 100%;
  width: 100%;
  height: 1px;
  min-height: 1px;
`