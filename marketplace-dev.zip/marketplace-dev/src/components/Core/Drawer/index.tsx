import React, { RefObject, useEffect } from "react";
import styled from "styled-components";
import Divider from "../Divider";
import Scrollbar from "smooth-scrollbar";

interface DrawerProps {
  active: boolean
  title: string
  children?: React.ReactChild | React.ReactChild[]
  primaryAction?: React.ReactNode
  secondaryAction?: React.ReactNode
  bottom?: boolean
  onClose: () => void
}

export default function Drawer(props: DrawerProps): JSX.Element {
  const scrollable: RefObject<HTMLDivElement> = React.createRef()

  useEffect(() => {
    if (!!scrollable.current) {
      Scrollbar.init(scrollable.current, { continuousScrolling: false, alwaysShowTracks: true })
    }
  }, [props])

  return (
    <Style className={`${props.active ? 'active' : ''} ${props.bottom ? 'bottom' : ''}`}>
      <div className="content-wrapper p-2">
        <div className="flex mb-1 px-2 justify-between">
          <div>
            {props.title}
          </div>
          <div className="flex items-center">
            {props.primaryAction}
          </div>
        </div>
        <Divider/>

        <div ref={scrollable} className="content p-2">
          {props.children}
        </div>

        {!props.bottom && props.secondaryAction && <>
            <Divider/>
            <div className="px-2 pt-3 pb-2 text-right w-full">
              {props.secondaryAction}
            </div>
        </>}
      </div>
      <div className="mask" onClick={() => props.onClose()}></div>
    </Style>
  )
}

const Style = styled.div`
  display: none;
  height: 100%;
  opacity: 0;
  flex-direction: row;
  position: absolute;
  width: 100%;
  transition: opacity 200ms, z-index 200ms;
  z-index: -1;
  
  &.bottom {
    flex-direction: column;
    
    .content-wrapper {
      order: 1
    }
  }
  
  &.active {
    display: flex;
    opacity: 1;
    z-index: 2;
    
    .content-wrapper {
      opacity: 1;
      flex-basis: auto;
      min-width: 300px;
      max-width: 40%;
    }
    
    &.bottom .content-wrapper {
      flex-basis: 40%;
      min-height: 200px;
      min-width: auto;
      max-width: none;
    }
  }
  
  .mask {
    flex: 1 1 auto;
    background-color: rgba(0, 0, 0, 0.45);
    cursor: pointer;
  }
  
  .content-wrapper {
    display: flex;
    flex-direction: column;
    opacity: 0;
    flex: 0 1 0;
    background-color: rgba(30, 30, 30, 0.95);
    transition: all 100ms;
    border-right: 1px solid rgba(169, 229, 255, 0.3);
    
    .content {
      text-shadow: none;
      flex: 1 1 auto;
    }
  }
  
  .close-btn {
    cursor: pointer;
    color: #fff;
    transition: all 100ms;
    
    &:hover {
      color: #a2dbf4;
    }
  }
`