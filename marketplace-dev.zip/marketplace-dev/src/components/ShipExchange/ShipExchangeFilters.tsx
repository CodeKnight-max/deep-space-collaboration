import React from "react";
import Drawer from "../Core/Drawer";
import ButtonAlt from "../Core/ButtonAlt/ButtonAlt";
import getBreakpoints from "../../services/responsive";
import styled from "styled-components";
import Switch from "react-switch";
import { SHIP_CORE_TYPES, SHIP_SELECT_LIST, SHIP_TYPES, STAT_NAMES, TextureColors } from "../../constants";
import {
  useFilterData,
  useRemoveFilterData,
  useShipSelects,
  useUpdateFilterData,
  useUpdateShipSelects
} from "../../state/others/hooks";
import { useRouter } from "next/router";
import { isString } from "lodash";
import StarRatingComponent from 'react-star-rating-component';
import { FaSortAmountDownAlt, FaSortAmountUp } from "react-icons/fa";
import { RiCloseCircleFill } from "react-icons/ri";

interface OutpostFiltersProps {
  active: boolean
  isActivityView?: boolean
  onClose: () => void
}

export default function ShipExchangeFilters(props: OutpostFiltersProps): JSX.Element {
  const breakpoints = getBreakpoints()

  const removeFilterData = useRemoveFilterData();
  const filterData = useFilterData();
  const updateFilterData = useUpdateFilterData();
  const shipSelects = useShipSelects();
  const updateShipSelects = useUpdateShipSelects();
  const router = useRouter();
  const handleReset = () => {
    removeFilterData();
    props.onClose()
    router.push({ query: {} })
  }
  const handleRating = nextValue => {
    handleOnChange(Number(nextValue), 'star')
  }
  const handleStarReSet = () => {
    handleOnChange(0, 'star');
  }
  const handleTextureReSet = () => {
    handleOnChange(-1, 'textureType');
  }
  const handleOnChange = (value, name) => {
    let data = { ...filterData, ...(props.isActivityView ? { view: 'activity' } : {}) };
    value = isString(value) ? value.trim() : value;
    value = (Number(value) === null || value === '') ? value : Number(value)
    if (name === 'minPrice' || name === 'minStatus' || name === 'minShipLevel') {
      if (name === 'minStatus' && value > 100) value = 100;
      if (name === 'minShipLevel' && value > 570) value = 570;
      value = (isNaN(value) || value === '') ? '' : value;
    }
    if (name === 'maxPrice' || name === 'maxStatus' || name === 'maxShipLevel') {
      value = (isNaN(value) || value === '') ? '' : value;
      if (name === 'maxStatus' && value > 100) value = 100;
      if (name === 'maxShipLevel' && value > 570) value = 570;
    }

    if (name === 'priceUp' || name === 'shipStatsUp' || name === 'shipLevelUp' || name === 'starUp' || name === 'textureTypeUp') {
      updateFilterData({ ...data, sortType: name, [name]: value });
      router.push({
        query: { ...data, sortType: name, [name]: value }
      })
    } else {
      if (name === 'minPrice' || name == "maxPrice") {
        updateFilterData({ ...data, sortType: "priceUp", [name]: value });
        router.push({
          query: { ...data, sortType: "priceUp", [name]: value }
        })
      } else if (name === 'minStatus' || name === 'maxStatus' || name === 'shipStatus') {
        updateFilterData({ ...data, sortType: "shipStatsUp", [name]: value });
        router.push({
          query: { ...data, sortType: "shipStatsUp", [name]: value }
        })
      } else if (name === 'minShipLevel' || name === 'maxShipLevel') {
        updateFilterData({ ...data, sortType: "shipLevelUp", [name]: value });
        router.push({
          query: { ...data, sortType: "shipLevelUp", [name]: value }
        })
      } else if (name === 'star') {
        if (value != 0) {
          if (data.sortType === 'starUp') {
            updateFilterData({ ...data, sortType: "initial", [name]: value });
            router.push({
              query: { ...data, sortType: "initial", [name]: value }
            })
          } else {
            updateFilterData({ ...data, [name]: value });
            router.push({
              query: { ...data, [name]: value }
            })
          }
        } else {
          updateFilterData({ ...data, sortType: "starUp", [name]: value });
          router.push({
            query: { ...data, sortType: "starUp", [name]: value }
          })
        }
      } else if (name === 'textureType') {
        if (value != -1) {
          if (data.sortType === 'textureTypeUp') {
            updateFilterData({ ...data, sortType: "initial", [name]: value });
            router.push({
              query: { ...data, sortType: "initial", [name]: value }
            })
          } else {
            updateFilterData({ ...data, [name]: value });
            router.push({
              query: { ...data, [name]: value }
            })
          }
        } else {
          updateFilterData({ ...data, sortType: "textureTypeUp", [name]: value });
          router.push({
            query: { ...data, sortType: "textureTypeUp", [name]: value }
          })
        }
      } else if (name === 'newListing') {
        if (value) {
          updateFilterData({ ...data, [name]: value, 'mySale': false });
          router.push({
            query: { ...data, [name]: value, 'mySale': false }
          })
        } else {
          updateFilterData({ ...data, [name]: value, 'myListing': false });
          router.push({
            query: { ...data, [name]: value, 'myListing': false }
          })
        }
      } else {
        updateFilterData({ ...data, [name]: value });
        router.push({
          query: { ...data, [name]: value }
        })
      }
    }
  }

  return (
    <Drawer active={props.active}
            title="Filters"
            onClose={props.onClose}
            /*primaryAction={
              <ButtonAlt text="Apply" className="text-xs" onClick={applyFilters} link/>
            }*/
            secondaryAction={
              <div className="flex justify-between">
                <ButtonAlt text="Cancel" className="text-xs" onClick={props.onClose} link/>
                <ButtonAlt text="Reset" className="text-xs" onClick={handleReset} link/>
              </div>
            }
            bottom={!breakpoints.lg}>
      <Styled>
        <div className="relative flex flex-col mt-5" style={{ fontSize: '14px' }}>
          <div className='w-full'>
            <div className="flex justify-center">
              {
                props.isActivityView ? (
                  <div className='flex justify-between w-full'>
                    <div>
                      <label className="flex items-center">
                        <span className="mr-1 text-sm">Sale</span>
                        <Switch onChange={() => { handleOnChange(filterData.newListing ^ 1, 'newListing') }} checked={filterData.newListing ? true : false} offColor={'#C7C7CC'} onColor={'#6F1DF4'} checkedIcon={false} uncheckedIcon={false} height={14} width={30} handleDiameter={16} />
                        <span className="ml-1 text-sm">Listing</span>
                      </label>
                    </div>
                    <div>
                      {
                        filterData.newListing ? (
                          <label className="flex items-center">
                            <Switch onChange={() => { handleOnChange(filterData.myListing ^ 1, 'myListing') }} checked={filterData.myListing ? true : false} offColor={'#C7C7CC'} onColor={'#6F1DF4'} checkedIcon={false} uncheckedIcon={false} height={14} width={30} handleDiameter={16} />
                            <span className="ml-1 text-sm">My Listing</span>
                          </label>
                        ) : (
                          <label className="flex items-center">
                            <Switch onChange={() => { handleOnChange(filterData.mySale ^ 1, 'mySale') }} checked={filterData.mySale ? true : false} offColor={'#C7C7CC'} onColor={'#6F1DF4'} checkedIcon={false} uncheckedIcon={false} height={14} width={30} handleDiameter={16} />
                            <span className="ml-1 text-sm">My Sale</span>
                          </label>
                        )
                      }
                    </div>
                  </div>
                ) : (
                  <div className="flex w-full justify-center">
                    <div>
                      <label className="flex items-center">
                        <Switch onChange={() => {
                          handleOnChange(filterData.newItem ^ 1, 'newItem')
                        }} checked={!!filterData.newItem} offColor={'#C7C7CC'} onColor={'#6F1DF4'}
                                checkedIcon={false} uncheckedIcon={false} height={14} width={30} handleDiameter={16}/>
                        <span className="ml-2 text-sm">New</span>
                      </label>
                    </div>
                  </div>
                )
              }
            </div>
          </div>
          <div className="flex items-center mb-3">
            <div className="text-sm label-width">Ship View</div>
            <div className="text-sm">
              <select className="text-sm text-center text-black bg-gray-300 rounded" value={shipSelects}
                      onChange={(e) => updateShipSelects(Number(e.target.value))} style={{ 'padding': "3px 12px" }}>
                {
                  SHIP_SELECT_LIST.map((val, key) => {
                    return <option value={val} key={key}>{val}</option>
                  })
                }
              </select>
            </div>
          </div>
          <div className="flex items-center mb-1">
            <div className="text-sm label-width">Price</div>
            <div className="flex items-center">
              <div>
                <input type='text' className="w-10 text-sm text-center text-black bg-gray-300 rounded input"
                       value={filterData.minPrice} onChange={(e) => {
                  handleOnChange(e.target.value, 'minPrice')
                }} style={{ 'padding': "3px 0px" }} placeholder="min"/>
              </div>
              <div className="ml-2">
                <input type='text' className="w-10 text-sm text-center text-black bg-gray-300 rounded input"
                       value={filterData.maxPrice} onChange={(e) => {
                  handleOnChange(e.target.value, 'maxPrice')
                }} style={{ 'padding': "3px 0px" }} placeholder="max"/>
              </div>
              <div className="ml-2 text-xl cursor-pointer" style={{ 'color': "#D400A6" }}>
                {
                  filterData.priceUp === 1 ? <FaSortAmountDownAlt onClick={() => handleOnChange(-1, 'priceUp')} /> : <FaSortAmountUp onClick={() => handleOnChange(1, 'priceUp')} />
                }
              </div>
            </div>
          </div>
          <div className="flex items-center mb-1">
            <div className="text-sm label-width">Ship Level</div>
            <div className="flex items-center">
              <div>
                <input type='text' className="w-10 text-sm text-center text-black bg-gray-300 rounded input"
                       value={filterData.minShipLevel} onChange={(e) => {
                  handleOnChange(e.target.value, 'minShipLevel')
                }} style={{ 'padding': "3px 0px" }} placeholder="min"/>
              </div>
              <div className="ml-2">
                <input type='text' className="w-10 text-sm text-center text-black bg-gray-300 rounded input"
                       value={filterData.maxShipLevel} onChange={(e) => {
                  handleOnChange(e.target.value, 'maxShipLevel')
                }} style={{ 'padding': "3px 0px" }} placeholder="max"/>
              </div>
              <div className="ml-2 text-xl cursor-pointer" style={{ 'color': "#D400A6" }}>
                {
                  filterData.shipLevelUp === 1 ? <FaSortAmountDownAlt onClick={() => handleOnChange(-1, 'shipLevelUp')} /> : <FaSortAmountUp onClick={() => handleOnChange(1, 'shipLevelUp')} />
                }
              </div>
            </div>
          </div>

          <div className="flex items-center mb-1">
            <div className="text-sm label-width">Ship Class</div>
            <div className="text-sm">
              <select className="text-sm text-center text-black bg-gray-300 rounded" onChange={(e) => {
                handleOnChange(e.target.value, 'shipClass')
              }} style={{ 'padding': "3px" }}>
                <option value={-1}> All</option>
                {
                  SHIP_TYPES && SHIP_TYPES.map((type, key) => {
                    if (key == Number(filterData.shipClass)) return <option value={key} style={{ 'padding': "3px" }}
                                                                            key={key} selected>{type}</option>
                    else return <option value={key} style={{ 'padding': "3px" }} key={key}>{type}</option>
                  })
                }
              </select>
            </div>
          </div>
          <div className="flex items-center mb-1">
            <div className="text-sm label-width">Core Type</div>
            <div className="text-sm">
              <select className="text-sm text-center text-black bg-gray-300 rounded" onChange={(e) => {
                handleOnChange(e.target.value, 'coreType')
              }} style={{ 'padding': "3px" }}>
                <option value={-1}>All</option>
                {
                  SHIP_CORE_TYPES.map((type, key) => {
                    if (key == filterData.coreType) return <option value={key} key={key} selected>{type}</option>
                    else return <option value={key} key={key}>{type}</option>
                  })
                }
              </select>
            </div>
          </div>
          <div className="w-full">
            <div className="flex items-center mb-1">
              <div className="text-sm label-width">Ship Stats</div>
              <div className="text-sm">
                <select className="text-sm text-center text-black bg-gray-300 rounded" onChange={(e) => {
                  handleOnChange(e.target.value, 'shipStatus')
                }} style={{ 'padding': "3px" }}>
                  {
                    STAT_NAMES && STAT_NAMES.map((type, key) => {
                      if (key == filterData.shipStatus) return <option value={key} key={key} selected>{type}</option>
                      else return <option value={key} key={key}>{type}</option>
                    })
                  }
                </select>
              </div>
            </div>
            <div className="flex items-center mb-1">
              <div className="label-width"></div>
              <div className="flex items-center">
                <div>
                  <input type='text' className="w-10 text-sm text-center text-black bg-gray-300 rounded input"
                         value={filterData.minStatus} onChange={(e) => {
                    handleOnChange(e.target.value, 'minStatus')
                  }} style={{ 'padding': "3px 0px" }} placeholder="min"/>
                </div>
                <div className="ml-2">
                  <input type='text' className="w-10 text-sm text-center text-black bg-gray-300 rounded input"
                         value={filterData.maxStatus} onChange={(e) => {
                    handleOnChange(e.target.value, 'maxStatus')
                  }} style={{ 'padding': "3px 0px" }} placeholder="max"/>
                </div>
                <div className="ml-2 text-xl cursor-pointer" style={{ 'color': "#D400A6" }}>
                  {
                    filterData.shipStatsUp === 1 ? <FaSortAmountDownAlt onClick={() => handleOnChange(-1, 'shipStatsUp')} /> : <FaSortAmountUp onClick={() => handleOnChange(1, 'shipStatsUp')} />
                  }
                </div>
              </div>
            </div>
          </div>
          <div className="flex mt-2 mb-1">
            <div className="flex items-end justify-center w-4/12 text-sm"><span>Rating</span></div>
            <div className="w-8/12 ml-3">
              <div className="flex items-end">
                <div className='ship-rating'>
                  <StarRatingComponent
                    name="shipRating"
                    starCount={5}
                    value={filterData.star}

                    emptyStarColor={'#D1D5DB'}
                    onStarClick={handleRating}
                  />
                </div>
                <div className="w-2/12 ml-2 text-xl text-right cursor-pointer" style={{ 'color': "#D400A6" }}>
                  {
                    (filterData.star == 0) ? (
                      filterData.starUp === 1 ? <FaSortAmountDownAlt onClick={() => handleOnChange(-1, 'starUp')} /> : <FaSortAmountUp onClick={() => handleOnChange(1, 'starUp')} />
                    ) : (
                      <RiCloseCircleFill onClick={() => { handleStarReSet() }} />
                    )
                  }
                </div>
              </div>
            </div>
          </div>
          <div className="flex items-center mb-3 mb-1">
            <div className="flex items-end justify-center w-4/12 text-sm"><span>Texture</span></div>
            <div className='w-8/12 ml-3'>

              <div className="flex items-center text-sm w-76">
                <div className='flex w-full'>
                  {
                    TextureColors.map((color, key) => {
                      return (
                        <div key={key}
                             className={`texture-section rounded-full cursor-pointer ${key == filterData.textureType ? 'texture-active' : ''}`}
                             onClick={() => handleOnChange(key, 'textureType')}
                             style={{ backgroundColor: color }}></div>
                      )
                    })
                  }
                </div>
                <div className="w-3/12 ml-2 text-xl text-left cursor-pointer" style={{ 'color': "#D400A6" }}>
                  {
                    (filterData.textureType == -1) ? (
                      filterData.textureTypeUp == 1 ? <FaSortAmountDownAlt onClick={() => handleOnChange(-1, 'textureTypeUp')} /> : <FaSortAmountUp onClick={() => handleOnChange(1, 'textureTypeUp')} />
                    ) : (
                      <RiCloseCircleFill onClick={() => { handleTextureReSet() }} />
                    )
                  }
                </div>
              </div>
            </div>
          </div>
        </div>
      </Styled>
    </Drawer>
  )
}

const Styled = styled.div`
  .active-filter-msg {
    padding: 6px 12px;
    font-size: 12px;
    border-radius: 4px;
    color: white;
    cursor: not-allowed;
    font-weight: bold;
    background-color: #d200ad;
    transition: 1s;
  }

  .label-width {
    width: 87px;
  }

  .texture-section {
    margin: 0 3px;
    overflow: hidden;
    transition: .3s;
    width: 16px;
    height: 16px;
  }

  .texture-section:hover {
    box-shadow: 0 0 2px 4px #cfcece;
  }

  .texture-active {
    box-shadow: 0 0 2px 4px #cfcece;
  }

  .ship-rating {
    line-height: 0.87;
  }

  .ship-rating .dv-star-rating {
    font-size: 26px;
    display: flex !important;
    flex-direction: row-reverse;
    align-items: center;
  }
`;
