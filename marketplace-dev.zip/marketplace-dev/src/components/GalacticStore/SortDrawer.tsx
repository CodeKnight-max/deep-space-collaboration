import React from "react";
import Drawer from "../Core/Drawer";

interface SortDrawerProps {
  active: boolean
  onClose: () => void
}

export default function SortDrawer(props: SortDrawerProps): JSX.Element {
  return (
    <Drawer active={props.active}
            title="Sort"
            onClose={props.onClose}/>
  )
}
