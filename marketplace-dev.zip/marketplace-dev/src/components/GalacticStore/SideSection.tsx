import Image from "next/image";
import bnbLogo from '../../asset/image/icons/bnb_logo.svg'
import dpsLogo from '../../asset/image/icons/dps_logo.svg'
import getBreakpoints from "../../services/responsive";
import { AiFillPlusCircle, AiOutlineClose, AiOutlineLoading } from "react-icons/ai";
import React, { RefObject, useEffect, useState } from "react";
import styled from "styled-components";
import Scrollbar from "smooth-scrollbar";
import Divider from "../Core/Divider";
import { OutpostRoute } from "../../interface/outpost/outpostRoute";
import Link from "next/link";
import { DPS } from "@deepspace-game/sdk";
import { useTokenBalance } from "../../state/wallet/hooks";
import { useActiveWeb3React } from "../../hooks";
import SwapModal from "../SwapModal";

interface SideSectionProps {
  routes: OutpostRoute[]
  activeParent: string
  activeChild?: string
  onRouteClick: () => void
  onClose: () => void
  getChildRoutes?: () => Promise<OutpostRoute[]>
}

export default function SideSection(props: SideSectionProps): JSX.Element {
  const scrollable: RefObject<HTMLDivElement> = React.createRef()
  const breakpoints = getBreakpoints()
  const { account, chainId
  } = useActiveWeb3React()
  const userDpsBalance = useTokenBalance(account, DPS[chainId])

  const [activeRouteChildren, setActiveRouteChildren] = useState<OutpostRoute[] | null>([])
  const [showSwapModal, setShowSwapModal] = useState(false)
  const [onRampDefault, setOnRampDefault] = useState(false)

  useEffect(() => {
    if (!!scrollable.current) {
      Scrollbar.init(scrollable.current, { continuousScrolling: false, alwaysShowTracks: true })
    }
  }, [scrollable, activeRouteChildren])

  useEffect(() => {
    if (props.getChildRoutes) {
      setActiveRouteChildren(null)
      props.getChildRoutes().then((routes) => {
        setActiveRouteChildren(routes)
      })
    }
  }, [props])

  const getRelevantClass = (routeKey: string) => {
    if (isActiveChild(routeKey))
      return 'menu-entry__child_active'
    return isActiveParent(routeKey) ? 'menu-entry__active menu-entry__parent_active' : 'menu-entry'
  }

  const isActiveParent = (routeKey: string) => routeKey === props.activeParent
  const isActiveChild = (routeKey: string) => routeKey === props.activeChild

  const getDpsBalance = (): string => {
    const balance = userDpsBalance?.toSignificant(4) ?? '0'
    return parseFloat(balance).toLocaleString('en-US')
  }

  const isWalletConnected = (): boolean => !!account && !!chainId

  return (
    <Style className={`${breakpoints.lg ? '' : 'handset'} flex flex-col relative h-full sidenav`}>
      <SwapModal show={showSwapModal} onRampDefault={onRampDefault} onClose={() => setShowSwapModal(false)}/>

      <div className="h-72 flex flex-col">
        <div className="flex items-center p-5 h-28 min-h-[7rem]">
          <h2 className="title text-3xl w-full text-center uppercase my-3 font-bold">
            Outpost
          </h2>

          {!breakpoints.lg &&
              <AiOutlineClose onClick={props.onClose}
                              style={{
                                cursor: 'pointer',
                                fontSize: "22px",
                                position: "absolute",
                                top: ".5rem",
                                right: ".5rem"
                              }}/>}
        </div>

        <div className="relative flex items-center justify-center">
          { !isWalletConnected() &&
              <div className="no-wallet absolute z-10 mb-8 text-lg ">No wallet connected</div>
          }
          {/*TODO: When refactoring css, add this: -webkit-backdrop-filter:blur(4px);*/}
          <div className="flex px-8 py-1.5 items-center mb-7" style={{filter: isWalletConnected() ? 'none' : 'blur(4px)'}}>
            <div className="pr-4">
              <div className="outer-circle">
                <div className="inner-circle">
                  <div className="avatar" style={{ backgroundImage: `url(/images/test-avatar.png)` }}></div>
                </div>
              </div>
            </div>

            <div className="flex flex-col flex-auto">
              <div className="flex flex-col">
                <span className="accent text-lg px-2">Welcome</span>
                <Divider/>
                <span className="ml-7 uppercase text-right px-2">Stranger</span>
              </div>

              <div className="flex flex-col">
                <div className="mb-1">
                  <span className="accent text-lg px-2">Balance</span>
                  <Divider/>
                </div>

                <div className="flex flex-col items-center justify-between px-2">
                  <div className="flex justify-between items-center mb-0.5 w-full">
                    <AiFillPlusCircle className="ml-1 text-lg cursor-pointer transition-all plus-button"
                                      onClick={() => {
                                        setOnRampDefault(true)
                                        setShowSwapModal(true)
                                      }}/>
                    <div className="flex items-center">
                      <span className="uppercase text-xs mr-1.5">0</span>
                      <Image src={bnbLogo} width="20px" height="20px"/>
                    </div>
                  </div>

                  <div className="flex justify-between items-center w-full mt-1">
                    <AiFillPlusCircle className="ml-1 text-lg cursor-pointer transition-all plus-button"
                                      onClick={() => {
                                        setOnRampDefault(false)
                                        setShowSwapModal(true)
                                      }}/>
                    <div className="flex items-center">
                    <span className="uppercase text-xs mr-1.5">
                      { isWalletConnected() ?
                        userDpsBalance ? getDpsBalance() : <AiOutlineLoading className="animate-spin mr-3"/>
                        : '0'
                      }
                    </span>
                      <Image src={dpsLogo} width="20px" height="20px"/>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        </div>

        <Divider/>
      </div>

      <div ref={scrollable} className="flex flex-col flex-auto p-2 overflow-y-auto">
        {props.routes
          .map(route => (
            <div className="mb-2 last:mb-0 w-full"
                 key={route.key}>
              <Link href={route.path} passHref>
                <div className={getRelevantClass(route.key)} onClick={props.onRouteClick}>

                <span className="pr-4 flex items-center">
                  <Image src={route.icon} width="20px" height="20px" />
                </span>
                  <span className="text-lg">
                  {route.name.replace('.', '')}
                </span>
                </div>
              </Link>

              {isActiveParent(route.key) && route.hasChildren &&
                  <div className="children-wrapper w-full pb-2 pl-8">
                    {!activeRouteChildren && <span><AiOutlineLoading className="animate-spin"/></span>}
                    {activeRouteChildren && activeRouteChildren.map(route => (
                      <div className="mb-2 last:mb-0 w-full" key={route.key}>
                        <Link href={route.path} key={route.key} passHref>
                          <div className={getRelevantClass(route.key)} onClick={props.onRouteClick}>
                            <span className="pr-4 flex items-center">
                              <Image src={route.icon} width="20px" height="20px"/>
                            </span>
                            <span className="text-lg">
                              {route.name.replace('.', '')}
                            </span>
                          </div>
                        </Link>
                      </div>
                    ))}
                  </div>}
            </div>
          ))}
      </div>
    </Style>
  )
}

const Style = styled.div`
  background-color: rgba(0, 54, 77, 0.7);
  border: 2px solid #A9E5FFCC;
  border-right-color: #A9E5FF80;
  letter-spacing: 0.15em;
  text-shadow: 0 0 3px rgba(255, 255, 255, 0.7);
  min-width: 350px;

  &.handset {
    margin: 0;
    border: none;
    width: 100%;
    max-width: 425px;
    height: 100%;
    background-color: rgba(0, 54, 77, 1);
    min-width: auto;

    &:before, &:after {
      display: none;
    }
  }

  .title {
    text-shadow: 0 0 5px rgba(169, 229, 255, 0.7);
    letter-spacing: 0.2em;
  }

  .accent {
    color: #00aeef;
    text-shadow: none;
  }

  .outer-circle, .inner-circle {
    border: 2px solid rgba(199, 140, 42, 0.7);
    box-shadow: 0 0 8px rgba(169, 229, 255, 0.4);
  }

  .outer-circle, .inner-circle, .avatar {
    border-radius: 100%;
  }

  .outer-circle {
    padding: 7px;

    .inner-circle {
      background-color: rgba(0, 151, 227, 0.3);
      padding: 5px;

      .avatar {
        width: 5rem;
        height: 5rem;
        background-size: contain;
        border: 1px solid #a9e5ff;
      }
    }
  }
  
  .no-wallet {
    text-shadow: 1px 1px 10px black;
  }
  
  .plus-button:hover {
    color: #00aeef;
  }

  .menu-entry, .menu-entry__active, .menu-entry__child_active {
    display: flex;
    align-items: center;
    width: 100%;
    background-image: url("/images/ui/menu_item.svg");
    background-repeat: no-repeat;
    background-size: 100% 100%;
    transition: all 250ms;
    padding: 0.7rem 1.7rem;
    color: #fff;
    
    &.menu-entry:hover, &.menu-entry__child_active, &.menu-entry__parent_active {
      background-image: url("/images/ui/menu_item_hovered.svg");
      
      &.menu-entry:hover, &.menu-entry__parent_active {
        cursor: pointer;
      }
    }

    &:last-child {
      margin-bottom: 0;
    }

    &.menu-entry__active {
      background-image: url("/images/ui/menu_item_active.svg");
    }
  }
  
  .children-wrapper {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background: url("/images/ui/submenu_bg.svg") no-repeat 100% 100%;
  }
`