import styled from "styled-components";
import bnbLogo from "../../asset/image/icons/bnb_logo.svg";
import Image from "next/image";
import React from "react";
import { ethers } from "ethers";
import { bnb_decimal } from "../../constants";
import { GSItem } from "../../interface/galactic-store";

interface ItemTableProps {
  items: any[]
  itemsData: GSItem[]
  onClick: (item: any) => void
}

export default function ItemTable(props: ItemTableProps): JSX.Element {
  const getItemName = (itemId: string): string => {
    return props.itemsData.find(i => i.id === itemId)?.name ?? ''
  }
  const getItemListedQty = (itemId: string): number => {
    return props.itemsData.find(i => i.id === itemId)?.listedQty ?? 0
  }
  const getItemSoldQty = (itemId: string): number => {
    return props.itemsData.find(i => i.id === itemId)?.soldQty ?? 0
  }

  return (
    <Style>
        <thead>
        <tr>
          <th className="item-name"></th>
          <th>Supply</th>
          <th className="item-cost">
            <span><Image src={bnbLogo} width="20px" height="20px"/></span>
            Cost
          </th>
          <th>Listed</th>
          <th>Sold</th>
        </tr>
        </thead>

      <tbody>
      {props.items.map((item, key) =>
        <tr className="item-row" key={key} onClick={() => props.onClick(item)}>
          <td className="item-name">{getItemName(item.id)}</td>
          <td>{item.numLimit}</td>
          <td>{ethers.utils.formatUnits(item.price, bnb_decimal).toString()}</td>
          <td>{getItemListedQty(item.id)}</td>
          <td>{getItemSoldQty(item.id)}</td>
        </tr>
      )}
      </tbody>
    </Style>
  )
}

const Style = styled.table`
  width: 100%;
  margin-bottom: 2.5rem;
  padding: 10px 0 1rem;
  border-spacing: 0 0.7rem;
  border-collapse: separate;
  text-shadow: none;
  
  tr {
    height: fit-content;
    padding-bottom: 10px;

    &.item-row {
      background: url("/images/ui/list_item.svg") no-repeat 100% 100%;

      &:hover {
        background-image: url("/images/ui/list_item_active.svg");
        cursor: pointer;
      }
    }
    
    th, td {
      &:last-child {
        padding-right: 2rem;
      }
    }

    th {
      position: sticky;
      top: 0;
      height: 30px;
      
      &.item-cost {
        position: relative;
        
        > span {
          position: absolute;
          top: -20px;
          display: flex;
          justify-content: center;
          width: 100%;
        }
      }
      
      &:not(.item-name) {
        width: 100px;
      }
    }
    
    td {
      height: 45px;
      
      &:not(.item-name) {
        text-align: center;
      }
      
      &.item-name {
        text-shadow: 0 0 3px rgba(255, 255, 255, 0.7);
      }
      
      &:first-child {
        padding-left: 2rem;
      }
    }
  }
`
