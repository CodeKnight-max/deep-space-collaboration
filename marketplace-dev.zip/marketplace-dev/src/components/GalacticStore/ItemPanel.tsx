import Image from "next/image";
import React from "react";
import { ethers } from "ethers";
import { bnb_decimal } from "../../constants";
import bnbLogo from "../../asset/image/icons/bnb_logo.svg";
import ButtonAlt from "../Core/ButtonAlt/ButtonAlt";
import Panel from "../Core/Panel";
import { GSItem } from "../../interface/galactic-store";

interface ItemPanelProps {
  active: boolean
  item: any
  itemData: GSItem
  onHeaderClick: () => void
  onBuyClick: (item: any) => void
}

export default function ItemPanel(props: ItemPanelProps): JSX.Element {
  return (
    <Panel title={props.itemData.name} active={props.active}
           onHeaderClick={props.onHeaderClick}>
      <div className="property flex justify-between py-2 px-3 text-xs">
        <span>Supply</span>
        <span>{props.item.numLimit}</span>
      </div>
      <div className="property flex justify-between py-2 px-3 text-xs">
        <span>Cost</span>
        <span className="flex items-center">
                    <Image src={bnbLogo} width="15px" height="15px"/>
                    <span style={{ marginLeft: '.5rem' }}>
                      {ethers.utils.formatUnits(props.item.price, bnb_decimal).toString()}
                    </span>
                  </span>
      </div>
      <div className="property flex justify-between py-2 px-3 text-xs">
        <span>Listed</span>
        <span>{props.itemData.listedQty}</span>
      </div>
      <div className="property flex justify-between py-2 px-3 text-xs">
        <span>Sold</span>
        <span>{props.itemData.soldQty}</span>
      </div>
      <div className="flex justify-end my-2">
        <ButtonAlt text="Buy" onClick={() => props.onBuyClick(props.item)} primary/>
      </div>
    </Panel>
  )
}
