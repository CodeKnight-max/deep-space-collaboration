import React, { useState } from "react";
import Drawer from "../Core/Drawer";
import ButtonAlt from "../Core/ButtonAlt/ButtonAlt";
import getBreakpoints from "../../services/responsive";

interface FiltersDrawerProps {
  active: boolean
  hasConsumables: boolean
  hasNonConsumables: boolean
  actions: FilterActions
  onClose: () => void
}

interface FilterActions {
  itemType: (showConsumables: boolean) => void
}

export default function FiltersDrawer(props: FiltersDrawerProps): JSX.Element {
  const breakpoints = getBreakpoints()
  const defaultFilters = {
    itemType: props.hasConsumables ? 1 : 0
  }

  const [filterState, setFilterState] = useState(defaultFilters)

  const handleItemTypeSelect = e => {
    setFilterState({ ...filterState, itemType: Number.parseInt(e.target.value) })
  }

  const resetFilters = () => {
    setFilterState(defaultFilters)
  }

  const applyFilters = () => {
    props.actions.itemType(Boolean(filterState.itemType))
    props.onClose()
  }

  return (
    <Drawer active={props.active}
            title="Filters"
            onClose={props.onClose}
            secondaryAction={
                    <div className="flex justify-end">
                      <ButtonAlt text="Reset" className="text-xs mr-3" onClick={resetFilters} link/>
                      <ButtonAlt text="Apply" className="text-xs" onClick={applyFilters} link/>
                    </div>
                  }
            bottom={!breakpoints.lg}>
      <label className="text-sm" htmlFor="item-type">Item type</label>
      <select className="text-sm ml-10 cursor-pointer" id="item-type"
              value={filterState.itemType} onChange={handleItemTypeSelect}>
        {props.hasConsumables && <option value={1}>Consumables</option>}
        {props.hasNonConsumables && <option value={0}>Non-Consumables</option>}
      </select>
    </Drawer>
  )
}
