import { NextRequest, NextResponse } from "next/server";

// This file is for Dev & Local environments
// Use `public/_redirects` to impact Prod

const redirects = new Map<string, string>([
  ['/', '/outpost/ship-exchange'],
  ['/outpost', '/outpost/ship-exchange'],
  ['/outpost/ships', '/outpost/ship-exchange'],
  ['/outpost/resource-swap', '/outpost/resource-exchange'],
  ['/exchange/swap', '/outpost/ship-exchange'],
  ['/shipyard', '/shipyard/ships'],
  ['/inventory', '/inventory/ships']
])

export function middleware(request: NextRequest) {
  const redirectPath = redirects.get(request.nextUrl.pathname)
  if (redirectPath) {
    const redirectUrl = request.nextUrl.clone()
    redirectUrl.pathname = redirectPath
    return NextResponse.redirect(redirectUrl)
  }

  return NextResponse.next()
}

