import { OutpostRoute } from "./outpostRoute";

export default interface OutpostViewProps {
  getChildren: (children: OutpostRoute[]) => void
}