export interface OutpostRoute {
  key: string
  name: string
  path: string
  icon: string
  hasChildren?: boolean
}
