export const logPageView = () => {}

export const logEvent = (category = '', action = '') => {}
