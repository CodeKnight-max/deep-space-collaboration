import React, { useState } from 'react'
import SideSection from "../../components/GalacticStore/SideSection";
import getBreakpoints from "../../services/responsive";
import Default from "../../layouts/Default";
import styled from "styled-components";
import { AiFillCaretRight } from "react-icons/ai";
import { OutpostRoute } from "../../interface/outpost/outpostRoute";
import routes from "../../constants/outpost/routes";
import Head from "next/head";
import config from "../../config";

interface OutpostLayoutProps {
  children: React.ReactChildren
  parentKey: string
  childKey?: string
  getChildRoutes?: () => Promise<OutpostRoute[]>
}

export default function OutpostLayout (props: OutpostLayoutProps): JSX.Element {
  const breakpoints = getBreakpoints();
  const [sidePanelCollapsed, setSidePanelCollapsed] = useState(true)

  const toggleSidePanel = (): void => setSidePanelCollapsed(!sidePanelCollapsed)

  const onSidePanelWrapperClick = (e: any) => {
    if (!JSON.stringify(e.target['className']).includes('sidePanelHandsetWrapper')) {
      return
    }

    toggleSidePanel()
  }

  const configMetaData = () => {
    switch (config.ENVIRONMENT) {
      case 'DEVELOPMENT':
        return 'Dev'
      case 'PRODUCTION':
        return 'DPS'
      default:
        return 'Test'
    }
  }

  const children = (
    <Style className={`goldman-font flex w-full ${breakpoints.lg ? 'p-8' : 'p-0'}`}>
      <Head>
        <title>DEEPSPACE - Outpost | {configMetaData()}</title>
        <meta content={"DEEPSPACE - Outpost | " + `${configMetaData()}`} property="og:title" />
        <meta content={"DEEPSPACE - Outpost | " + `${configMetaData()}`} property="twitter:title" />
        <meta content="One of the crown jewels of the DEEPSPACE Metaverse is the Outpost. The Outpost is a decentralized exchange hub where you can buy, sell, and trade your ships, cores, and other upgradeable Smart NFTs with fellow explorers. You can use the marketplace to build limited edition ships and acquire other valuable collectible assets. Build up your fleet to explore, harvest, and fight your way through the DEEPSPACE universe!" name="description" />
        <meta content="One of the crown jewels of the DEEPSPACE Metaverse is the Outpost. The Outpost is a decentralized exchange hub where you can buy, sell, and trade your ships, cores, and other upgradeable Smart NFTs with fellow explorers. You can use the marketplace to build limited edition ships and acquire other valuable collectible assets. Build up your fleet to explore, harvest, and fight your way through the DEEPSPACE universe!" property="og:description" />
        <meta content="One of the crown jewels of the DEEPSPACE Metaverse is the Outpost. The Outpost is a decentralized exchange hub where you can buy, sell, and trade your ships, cores, and other upgradeable Smart NFTs with fellow explorers. You can use the marketplace to build limited edition ships and acquire other valuable collectible assets. Build up your fleet to explore, harvest, and fight your way through the DEEPSPACE universe!" property="twitter:description" />
        <meta property="og:type" content="website" />
        <meta content="summary_large_image" name="twitter:card" />
        <meta content="width=device-width, initial-scale=1" name="viewport" />
      </Head>

      <div
        className={`${breakpoints.lg ? 'wrapper' : `handset-wrapper ${sidePanelCollapsed ? 'collapsed' : 'w-full bg-black/75'}`} transition-all`}
        onClick={onSidePanelWrapperClick}>
        <SideSection routes={routes}
                     activeParent={props.parentKey}
                     activeChild={props.childKey}
                     onRouteClick={toggleSidePanel}
                     onClose={toggleSidePanel}
                     getChildRoutes={props.getChildRoutes}/>
        {sidePanelCollapsed &&
            <div className="flex column h-full justify-center">
                <div className="nav-tab flex column justify-center items-center"
                     onClick={() => setSidePanelCollapsed(false)}>
                    <AiFillCaretRight fontSize={10}/>
                </div>
            </div>}
      </div>

      <div className={`content-section ${breakpoints.lg ? '' : "handset"} flex-col flex-auto relative`}>
        {props.children}
      </div>
    </Style>
  )

  return Default({ children })
}

const Style = styled.div`
  .wrapper {
    flex: 0 0 20%;
  }
  
  .handset-wrapper {
    position: absolute;
    height: 100%;
    z-index: 20;
    overflow: hidden;
    
    &.collapsed .sidenav {
      display: none;
    }
    
    .nav-tab {
      margin: auto;
      height: 85px;
      width: 15px;
      left: 0;
      top: 0;
      z-index: 3;
      background: url("/images/ui/nav_tab.svg") no-repeat 100% 100%;
      cursor: pointer;
    }
  }
  
  .content-section {
    background-color: rgba(0, 0, 0, 0.5);
    border: 2px solid #A9E5FFCC;
    border-left: none;
    letter-spacing: 0.15em;
    text-shadow: 0 0 3px rgba(255, 255, 255, 0.7);

    &.handset {
      margin: 0;
      border: none;
      width: 100vw;

      &:before, &:after {
        display: none;
      }
    }
  }
`