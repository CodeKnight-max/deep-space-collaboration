'use client'

import React, { useState } from 'react'
import { BsChevronBarExpand } from 'react-icons/bs'
import Link from 'next/link'
import { socialEntries } from '@/constants/socials'
import ServiceStatus from '@/components/client/ServiceStatus'

export default function Footer({ children }: { children: React.ReactNode }) {
  // console.log("Finding-error-Footer")

  const [isExpanded, setIsExpanded] = useState(false)

  const toggleFooter = () => setIsExpanded(!isExpanded)

  const socials = socialEntries.map((e) => (
    <Link
      className="btn-ghost tooltip tooltip-left btn-xs btn-circle btn"
      key={e.href}
      href={e.href}
      data-tip={e.label}
      target="_blank"
    >
      {e.icon}
    </Link>
  ))

  return (
    <div className={`footer-wrapper hidden flex-col transition-all lg:flex ${isExpanded ? 'expanded' : ''}`}>
      <div className="mask invisible flex-auto cursor-pointer transition-all" onClick={toggleFooter} />

      <div className={`footer-content hidden transition-all ${isExpanded ? 'expanded' : ''}`}>
        <footer className="top-footer footer items-center bg-neutral px-4 pt-3 text-neutral-content">
          <div className="grid-flow-col items-center gap-4">
            <ServiceStatus className="flex items-center" />
          </div>

          <div className="grid-flow-col gap-6 place-self-center justify-self-end">
            <div className="flex items-center gap-3">{socials}</div>

            <button className="btn-ghost btn-xs btn gap-2" onClick={toggleFooter}>
              {isExpanded ? 'Collapse' : 'Expand'}
              <BsChevronBarExpand fontSize={20} />
            </button>
          </div>
        </footer>
        {children}
      </div>
    </div>
  )
}