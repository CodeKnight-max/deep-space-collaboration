import { TfiMenu } from 'react-icons/tfi'
import Link from 'next/link'
import EthIcon from '../Svg/Icons/EthIcon'
import BnbIcon from '../Svg/Icons/BnbIcon'
import { navigationEntries } from '@/constants/navigation'
import WalletConnectBtn from '@/components/client/WalletConnectBtn/WalletConnectBtn'

export default function Header() {
  // console.log("Finding-error-Header")

  const getChainLabel = (chain: string) => {
    switch (chain) {
      case 'ETH':
        return 'Ethereum Powered'
      case 'BNB':
        return 'BNB Chain Powered'
      default:
        return ''
    }
  }

  const getChainIcon = (chain: string) => {
    const size = '80%'

    switch (chain) {
      case 'ETH':
        return <EthIcon height={size} />
      case 'BNB':
        return <BnbIcon height={size} />
      default:
        return <></>
    }
  }

  const navEntries = navigationEntries.filter((e) => e.chain !=='ETH' ).map((e) => (
    <li key={e.href}>
      <Link href={e.href} className={`${e.isActive ? 'active' : ''} ${e.chain ? 'indicator' : ''}`}>
        {e.label}
        {e.chain && (
          <span
            className={`transition-all indicator-item indicator-bottom badge rounded-full
                                    w-7 h-7 p-0 ${e.isActive ? 'badge-primary' : 'opacity-0'}`}
          >
            <span
              className="flex items-center justify-center w-full h-full tooltip tooltip-bottom"
              data-tip={getChainLabel(e.chain)}
            >
              {getChainIcon(e.chain)}
            </span>
          </span>
        )}
      </Link>
    </li>
  ))

  return (
    <div className="header fixed top-0 h-16" >
      <div className="navbar">
        <div className="navbar-start">
          <div className="flex-none lg:hidden">
            <label htmlFor="drawer" className="btn btn-ghost">
              <TfiMenu fontSize={20} />
            </label>
          </div>

          <div className="indicator">
            <div className="dps-logo" />
          </div>
        </div>

        <div className="hidden navbar-center lg:flex">
          <ul className="gap-2 px-1 menu menu-horizontal">{navEntries}</ul>
        </div>

        <div className="navbar-end">
          <WalletConnectBtn />
        </div>
      </div>
    </div>
  )
}
