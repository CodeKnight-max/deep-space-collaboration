import Header from '@/components/shared/Header'
import Footer from '@/components/client/Layout/Footer'
import SharedFooter from '@/components/shared/Footer'
import LeaderBoard from "src/app/leaderboard/LeaderBoard"
import Tabs from 'src/app/leaderboard/Tabs'
import Users from 'src/app/leaderboard/Users'
import Drawer from '@/components/shared/Drawer'
import Profile from 'src/app/leaderboard/Profile'
import { UserContextProvider } from './leaderboard/context'


//export const runtime = 'edge' // 'nodejs' (default) | 'edge'

export default function Homepage({searchParams}:{searchParams: { [key: string]: number | undefined | string }}) {
  // console.log("Finding-error-page")

  const pageNumber = searchParams?.page
  const tabname = searchParams?.tab
  // console.log("search-->", searchParams)
  return <LeaderBoard>
    <input id="drawer" type="checkbox" className="drawer-toggle" />
    <div
      className="pt-16 overflow-x-hidden lg:pt-20 drawer-content lg:pb-14 lg:justify-center"
      style={{ display: 'block' }}
    >
      <Header />
      <div className='mt-5 text-center uppercase'>
        <span className='leaderboard-title text-xl lg:text-2xl tracking-widest border-b border-b-[#2b6a91]'>Combat Leaderboard</span>
      </div>
      <div className='mx-auto leaderboard-screen'>
        <Tabs tab={tabname}/>
        <div className='xl:flex xl:flex-row-reverse xl:mt-8'>
          <UserContextProvider>
            <div className='profile'><Profile /></div>
            <Users page={pageNumber} tab={tabname} />
          </UserContextProvider>
        </div>
      </div>
      <Footer>
        <SharedFooter />
      </Footer>
    </div>
    <Drawer />
  </LeaderBoard>
}
