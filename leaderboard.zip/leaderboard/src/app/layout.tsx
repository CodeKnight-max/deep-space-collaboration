import './globals.css'

//export const runtime = 'edge' // 'nodejs' (default) | 'edge'

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  console.log("Finding-error-layout")
  return (
    <html lang="en">
      <head>
        <link rel="icon" type="image/png" sizes="32x32" href="/images/icons/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="96x96" href="/images/icons/favicon-96x96.png" />
        <link rel="shortcut icon" href="/images/icons/favicon.ico" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700;800&family=Poppins:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Goldman:wght@400;700&family=Lato:wght@400;700&display=swap"
          rel="stylesheet"
        />

        <meta property="og:url" content="https://leaderboard.deepspace.game" />
        <meta property="og:title" content="DEEPSPACE Leaderboard" />
        <meta property="twitter:card" content="summary" />
        <meta property="fb:app_id" content="152351391599356" />
        <meta key="og:image" property="og:image" content="https://leaderboard.deepspace.game/images/og_image.webp" />
        <meta
          property="og:description"
          content="Bridge assets between blockchain(s) and the game!"
        />
      </head>
      <body>
        {children}
      </body>
    </html>
  )
}
