'use client'
import cn from 'classnames'
import { useRouter } from 'next/navigation'
import { useCreateQueryString } from './hooks'
import { findTabSlug, tabs } from './utils'
export default function TabsComponent({tab}:{tab:string|undefined|number}) {
  // console.log("Finding-error-Tabs")

  const tabSlug = findTabSlug(tab)
  const router = useRouter()
  console.log("router-->", tab)
  const createQueryString = useCreateQueryString()
  const handleClick  = (tab:string) => () => {
    router.push('/?' + createQueryString({ tab }))
  }
  return (
    <div className='flex justify-center mt-8 tabs'>
      {tabs.map(tab=>
        <div className={cn(`tab-item bg-center px-3 cursor-pointer text-xs bg-no-repeat bg-contain uppercase bg-[url('/images/leaderboard/tabBackground.svg')]`, {active:tab.key===tabSlug})} key={tab.key} onClick={handleClick(tab.key)}>
          {tab.label}
        </div>
      )}
    </div>
  )
}