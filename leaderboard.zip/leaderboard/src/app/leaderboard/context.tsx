'use client'

import React, { createContext, useState } from 'react'
interface UserContextProps {
    value: any
    setValue: (value: any) => void
}
export const UserContext = createContext<UserContextProps | undefined>(undefined)
export const UserContextProvider = ({ children }:{children:React.ReactNode}) => {
//   console.log("Finding-error-context")

    const [value, setValue] = useState<UserContextProps>()
    // console.log("context-", value)
    return (
       <UserContext.Provider value={{ value, setValue }}>
            {children}
       </UserContext.Provider>
    );
};