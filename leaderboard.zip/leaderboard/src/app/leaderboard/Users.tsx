import {redirect} from 'next/navigation'
import 'server-only'
import User from 'src/app/leaderboard/User'
import Pagination from '@/components/client/Pagination'
import { Config } from '@/config/config'
import { findTabSlug } from './utils'

export default async function Users({page, tab}:{page:number|undefined|string, tab:number|undefined|string}) {
  // console.log("Finding-error-Users")

  const tabSlug= findTabSlug(tab)
  let currentPage:number = 0
  if (typeof page  === 'number') currentPage = page
  else if (typeof page  === 'string')currentPage = +page
  const url = `${Config.backendUrl()}/api/Leaderboard/${tabSlug}/${currentPage}`
  let userItems:any[] = []
  let usersCount = 0
  try {
    const res = await fetch(url)
    const { total, items} =  await res.json()
    usersCount = total
    userItems = items
  } catch(e){
    console.log(e)
  }
  const itemsPerPage = 15
  if (currentPage !== undefined && currentPage < 0) {
    redirect("/")
  }
  const totalPages = Math.ceil(usersCount / itemsPerPage)
  if (userItems.length === 0) {
    redirect("/")
  }
  const users:any[] = userItems.map((item:any, index:number) => {
    const order = currentPage * itemsPerPage + index
    return {
      ...item,
      order
    }
  })
  return (<div className='w-full users-wrapper sm:w-[65%] md:w-[70%] sm:mx-auto'>
    <div className='table pl-2 pr-4 users border-spacing-y-2'>
      {users.map( (user:any)  => {
        return (<User key={user.id} user={user} firstUser={users[0]}/>)
      })}
    </div>
    <Pagination totalPages={totalPages} currentPage={currentPage} />
  </div>)
}