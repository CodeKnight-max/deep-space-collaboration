export const clamp = (number: number, boundOne: number, boundTwo: number) => {
  if (Math.min(number, boundOne) === number) {
    return boundOne
  }

  if (Math.max(number, boundTwo) === number) {
    return boundTwo
  }
  return number
}

export const relativeDiff = (a: number, b: number) => {
  return 100 * Math.abs((a - b) / ((a + b) / 2))
}

export const getRandomArbitrary = (min: number, max: number) => {
  return Math.random() * (max - min) + min
}
