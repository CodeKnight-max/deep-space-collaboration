'use client'

import React from 'react'
import { useRouter } from 'next/navigation'
import { useMediaQuery } from 'usehooks-ts'
import ReactPaginate from 'react-paginate'
import { useCreateQueryString } from '../../app/leaderboard/hooks'
//import 'react-responsive-pagination/themes/classic.css'
// 👆 classic theme, see below for other theme / css options

export default function Pagination({totalPages, currentPage}:{totalPages:number, currentPage:number}) {
  const router = useRouter()
  const isMobile = useMediaQuery('(max-width: 1030px)')
  const createQueryString = useCreateQueryString()
  const handlePageClick = (event: any) => {
    if (event.selected >= 0 && +currentPage !== event.selected)router.push('/?' + createQueryString({ page:event.selected }))
  }

  return (
      <ReactPaginate
        breakLabel="..."
        nextLabel=">"
        initialPage={+currentPage}
        onPageChange={handlePageClick}
        pageRangeDisplayed={isMobile ? 1:5}
        marginPagesDisplayed={1}
        pageCount={totalPages}
        previousLabel="<"
        pageClassName="page-item"
        pageLinkClassName="page-link"
        previousClassName="page-item"
        previousLinkClassName="page-link"
        nextClassName="page-item"
        nextLinkClassName="page-link"
        breakClassName="page-item"
        breakLinkClassName="page-link"
        containerClassName="pagination"
        activeClassName="active"
      />
  )
}
