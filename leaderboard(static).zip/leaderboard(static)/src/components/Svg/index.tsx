export { default as Svg } from "./Svg";
export type { SvgProps } from "./types";
