import Image from 'next/image'
import Link from 'next/link'

export default function Footer() {

  return (
    <footer className="footer flex-auto bg-neutral px-10 pt-7 text-neutral-content">
      <div className="flex flex-col gap-0">
        <Image
          className="opacity-80 mb-2"
          src="/images/icons/chainify.svg"
          alt="Chainify LLC"
          width={210}
          height={50}
        />

        <p>
          © 2023{' '}
          <Link target="_blank" href="https://www.chainifylabs.com/" className="link">
            Chainify LLC
          </Link>
          &nbsp;| All Rights Reserved
        </p>

        <div className="flex gap-2">
          <Link className="link-hover link" href="https://legal.deepspace.game/cookie-policy">
            Cookie Policy
          </Link>
          <Link className="link-hover link" href="https://legal.deepspace.game/privacy-policy">
            Privacy Policy
          </Link>
          <Link className="link-hover link" href="https://legal.deepspace.game/terms-conditions">
            Terms & Conditions
          </Link>
        </div>
      </div>
    </footer>
  )
}

/*const Style = styled.div`
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: auto;
  z-index: 50;

  &.expanded {
    top: 0;

    .mask {
      background-color: rgba(21, 25, 30, 0.4);
      visibility: visible;
    }
  }

  .footer-content {
    display: flex;
    flex-direction: column;
    height: 56px;
    overflow: hidden;
    background: url('/images/ui/header_wallpaper.webp') center bottom;
    background-size: cover;

    &.expanded {
      height: 180px;
    }
  }

  .footer {
    background-color: #0d0b10cc;

    &.top-footer {
      border-top: 1px solid #351268;
    }
  }
`*/
