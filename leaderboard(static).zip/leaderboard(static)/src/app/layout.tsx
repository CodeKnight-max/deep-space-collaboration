import './globals.css'
import Header from '@/components/shared/Header'
import Footer from '@/components/client/Layout/Footer'
import SharedFooter from '@/components/shared/Footer'
import LeaderBoard from "src/app/leaderboard/LeaderBoard"
import Tabs from 'src/app/leaderboard/Tabs'
import Drawer from '@/components/shared/Drawer'
import Profile from 'src/app/leaderboard/Profile'
import { UserContextProvider } from './leaderboard/context'


//export const runtime = 'edge' // 'nodejs' (default) | 'edge'

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" type="image/png" sizes="32x32" href="/images/icons/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="96x96" href="/images/icons/favicon-96x96.png" />
        <link rel="shortcut icon" href="/images/icons/favicon.ico" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700;800&family=Poppins:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Goldman:wght@400;700&family=Lato:wght@400;700&display=swap"
          rel="stylesheet"
        />

        <meta property="og:url" content="https://leaderboard.deepspace.game" />
        <meta property="og:title" content="DEEPSPACE Leaderboard" />
        <meta property="twitter:card" content="summary" />
        <meta property="fb:app_id" content="152351391599356" />
        <meta key="og:image" property="og:image" content="https://leaderboard.deepspace.game/images/og_image.webp" />
        <meta
          property="og:description"
          content="Bridge assets between blockchain(s) and the game!"
        />
      </head>
      <body>
      <LeaderBoard>
    <input id="drawer" type="checkbox" className="drawer-toggle" />
    <div
      className="pt-16 overflow-x-hidden lg:pt-20 drawer-content lg:pb-14 lg:justify-center"
      style={{ display: 'block' }}
    >
      <Header />
      <div className='mt-5 text-center uppercase leaderboard-title'>
        <span className='text-xl lg:text-2xl tracking-widest border-b border-b-[#2b6a91]'>Combat Leaderboard</span>
      </div>
      <div className='mx-auto leaderboard-screen'>
        <Tabs />
        <div className='xl:flex xl:flex-row-reverse xl:mt-8'>
          <UserContextProvider>
            <div className='profile'><Profile /></div>
            {children}
          </UserContextProvider>
        </div>
      </div>
      <Footer>
        <SharedFooter />
      </Footer>
    </div>
    <Drawer />
  </LeaderBoard>
      </body>
    </html>
  )
}
