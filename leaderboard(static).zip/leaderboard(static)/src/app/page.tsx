import {lazy,  Suspense } from 'react'
import Users from 'src/app/leaderboard/Users'
import Loading from './leaderboard/Loading'

//export const runtime = 'edge' // 'nodejs' (default) | 'edge'
// const LazyData = lazy(() => import("./leaderboard/Users"));
export default function Homepage() {
  return (
    <>
      <Suspense fallback = {<Loading/>}>
        <Users />
        {/* <LazyData/> */}
      </Suspense>
    </>
  )
}
