'use client'

import React from 'react'
import styled from 'styled-components'
import { WagmiConfig, createConfig, configureChains} from 'wagmi'
import { publicProvider } from 'wagmi/providers/public'

// import { CoinbaseWalletConnector } from 'wagmi/connectors/coinbaseWallet'
import { InjectedConnector } from 'wagmi/connectors/injected'
import { WalletConnectConnector } from 'wagmi/connectors/walletConnect'
import { Config } from '@/config/config'

const { chains, publicClient, webSocketPublicClient  } = configureChains(
  [...Config.chains()],
  [publicProvider()],
  { pollingInterval: 10_000 },
)
const projectId = 'eb8e243732621415799f100d119a1c55' 
// Set up wagmi config
const config = createConfig({
  autoConnect: true,
  connectors: [
    new InjectedConnector({
      chains,
      options: {
        name: 'MetaMask',
        shimDisconnect: true,
      },
    }),
    new WalletConnectConnector({
      chains,
      options: {
        projectId,
        showQrModal: true
      },
    }),
  ],
  publicClient,
  webSocketPublicClient,
})

export default function LeaderBoard({children}:{children:React.ReactNode}) {
  return <>
    <WagmiConfig config={config}>
      <Style className="drawer">
        {children}
      </Style>
    </WagmiConfig>
  </>
}

const Style = styled.div`
  .drawer-content {
    background: url('/images/leaderboard/background.svg');
    background-position: center center;
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: fixed;
    overflow-y: auto;
    height: 100dvh;
  }
`
