'use client'
import cn from 'classnames'
import { useRouter, useSearchParams } from 'next/navigation'
import { useCreateQueryString } from './hooks'
import { findTabSlug, tabs } from './utils'
export default function TabsComponent() {
  const searchParams = useSearchParams()
  const tab = searchParams.get('tab')
  const tabSlug = findTabSlug(tab)
  const router = useRouter()
  const createQueryString = useCreateQueryString()
  const handleClick  = (tab:string) => () => {
    router.push('/?' + createQueryString({ tab }))
  }
  return (
    <div className='flex justify-center mt-8 tabs'>
      {tabs.map(tab=>
        <div className={cn(`tab-item bg-center px-3 cursor-pointer text-xs bg-no-repeat bg-contain uppercase bg-[url('/images/leaderboard/tabBackground.svg')]`, {active:tab.key===tabSlug})} key={tab.key} onClick={handleClick(tab.key)}>
          {tab.label}
        </div>
      )}
    </div>
  )
}