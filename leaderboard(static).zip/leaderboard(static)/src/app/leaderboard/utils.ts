export const tabs = [
  {
    key:'wagered',
    label:'Wagered'
  },
  {
    key:'unwagered',
    label:'Unwagered'
  },
  {
    key:'experience',
    label:'Experience'
  }
 ]
export const findTabSlug = (tab:string|undefined|number|null):string => {
  let tabSlug = tabs[0]['key']
  const tabItem = tabs.find(item=>item.key===tab)
  if (tabItem){
    tabSlug = tabItem.key
  }
  return tabSlug
}
 