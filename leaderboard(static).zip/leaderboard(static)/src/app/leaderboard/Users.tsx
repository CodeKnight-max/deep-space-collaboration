'use client'
import {useSearchParams, useRouter} from 'next/navigation'
import { useAccount } from 'wagmi'
import useSWR from 'swr'
import axios from 'axios'
import User from 'src/app/leaderboard/User'
import Pagination from '@/components/client/Pagination'
import { Config } from '@/config/config'
import { findTabSlug } from './utils'

const fetcher = (url:string) => axios.get(url).then(res => res.data)

export default function Users() {
  const searchParams = useSearchParams()
  const tab = searchParams.get('tab')
  const tabSlug= findTabSlug(tab)
  const router = useRouter()
  let currentPage:number = 0
  const page = searchParams.get('page')
  if (typeof page  === 'number') currentPage = page
  else if (typeof page  === 'string')currentPage = +page
  let url = `${Config.backendUrl()}/api/Leaderboard/${tabSlug}/${currentPage}`
  const { address } = useAccount()
  if (address !==undefined) url += `?address=${address}`
  const { data, error } = useSWR(url, fetcher, {suspense: true})
  let userItems:any[] = data?.items??[]
  let usersCount = data?.total ?? 0
  const itemsPerPage = 15
  if (currentPage !== undefined && currentPage < 0) {
    router.push('/')
  }
  const totalPages = Math.ceil(usersCount / itemsPerPage)
  if (userItems.length === 0 && currentPage!==0) {
    router.push('/')
  }
  const users:any[] = userItems.map((item:any, index:number) => {
    const order = currentPage * itemsPerPage + index
    return {
      ...item,
      order
    }
  })
  return (<div className='w-full users-wrapper sm:w-[65%] md:w-[70%] sm:mx-auto'>
    <div className='table pl-2 pr-4 users border-spacing-y-2'>
      {users.map( (user:any)  => {
        return (<User key={user.order} user={user} firstUser={users[0]}/>)
      })}
    </div>
    {totalPages>0}<Pagination totalPages={totalPages} currentPage={currentPage} />
  </div>)
}