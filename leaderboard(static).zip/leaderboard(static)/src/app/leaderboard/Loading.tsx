import loading from "../../../public/icons/Loading.gif";
const Loading = () => {
    return (
        <div className="text-center block mx-auto my-auto">
            <h1>Loading...</h1>
            <img className="object-contain w-80 mx-auto" src={loading.src} alt="wow" />
        </div>
    )
}
export default Loading;