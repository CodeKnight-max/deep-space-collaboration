'use client'

import React, { createContext, useState } from 'react'
interface UserContextProps {
    value: any
    setValue: (value: any) => void
}
export const UserContext = createContext<UserContextProps | undefined>(undefined)
export const UserContextProvider = ({ children }:{children:React.ReactNode}) => {
    const [value, setValue] = useState<UserContextProps>()
    return (
       <UserContext.Provider value={{ value, setValue }}>
            {children}
       </UserContext.Provider>
    );
};