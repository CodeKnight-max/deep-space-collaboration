'use client'

import React, {useContext, useEffect} from 'react'
import { useSearchParams } from 'next/navigation'
import cn from 'classnames'
import { UserContext } from './context'
import { findTabSlug } from './utils'

export default function User({ user, firstUser }: { user: any, firstUser:any }) {
  const searchParams = useSearchParams()
  const tabSlug = findTabSlug(searchParams.get('tab'))
  /*const isSameAddress = (walletAddress:string | undefined, user:any) => {
    if (walletAddress === '0x1111135769C39ec4ae7df57D52C3f62158096aE2') {
      console.log("check this", "0x402995d66fd12c947785c1514495423b64175051" === user?.walletAddress)
      return "0x402995d66fd12c947785c1514495423b64175051" === user?.walletAddress  
    }
    return walletAddress?.toLowerCase() === user?.walletAddress
  }*/
  const classNameBackgroundByUser = (user: any) => {
    if (user.order === 0) return `username flex bg-no-repeat pb-2 pt-1.5 mb-1 h-8 
      bg-[url('/images/leaderboard/firstLineMobile.svg')] 
      lg:bg-[url('/images/leaderboard/firstLineDesktop.svg')]
      bg-center
      max-[420px]:bg-contain
      cursor-pointer
      `
    if (user.order === 1) return `username flex bg-no-repeat pb-2 pt-1.5 mb-1 h-8 
      bg-[url('/images/leaderboard/secondLineMobile.svg')]
      lg:bg-[url('/images/leaderboard/secondLineDesktop.svg')]
      bg-center
      max-[420px]:bg-contain
      cursor-pointer`
    if (user.order === 2) return `username flex bg-no-repeat pb-2 pt-1.5 mb-1 h-8 
      bg-[url('/images/leaderboard/thirdLineMobile.svg')] 
      lg:bg-[url('/images/leaderboard/thirdLineDesktop.svg')]
      bg-center
      max-[420px]:bg-contain
      cursor-pointer`
    /*if (isSameAddress(address, user)) return `
      table-row bg-no-repeat pb-2 pt-1 mb-1 h-8 
      bg-[url('/images/leaderboard/selfLineMobile.svg')] 
      lg:bg-[url('/images/leaderboard/selfLineDesktop.svg')]
      max-[420px]:bg-cover`*/
    return `username flex bg-no-repeat pb-2 pt-1.5 mb-1 h-8 
      bg-[url('/images/leaderboard/normalLineMobile.svg')] 
      lg:bg-[url('/images/leaderboard/normalLineDesktop.svg')]
      bg-center
      max-[420px]:bg-contain
      cursor-pointer`
  }
  const positionByUser = (user: any) => {
    if (user.order === 0) return <>1<sup>ST</sup></>
    if (user.order === 1) return <>2<sup>ND</sup></>
    if (user.order === 2) return <>3<sup>RD</sup></>
    return <>{user.order + 1}<sup>TH</sup></>
  }
  const classNameIconByUser = (user: any) => {
    if (user.order === 0) return `relative right-[-1rem] icon table-cell w-8 bg-[url('/images/leaderboard/firstIconMobile.svg')] bg-no-repeat bg-center bg-contain`
    if (user.order === 1) return `relative right-[-1rem] icon table-cell w-8 bg-[url('/images/leaderboard/secondIconMobile.svg')] bg-no-repeat bg-center bg-contain`
    if (user.order === 2) return `relative right-[-1rem] icon table-cell w-8 bg-[url('/images/leaderboard/thirdIconMobile.svg')] bg-no-repeat bg-center bg-contain`
    //if (isSameAddress(address, user)) return `table-cell w-10 bg-[url('/images/leaderboard/selfIconMobile.svg')] bg-no-repeat bg-center`    
    return `relative right-[-1rem] icon table-cell w-8 bg-[url('/images/leaderboard/normalIconMobile.svg')] bg-no-repeat bg-center bg-contain`
  }
  const classNameDivideByUser = (user: any) => {
    if (user.order === 0) return `divide bg-[url('/images/leaderboard/firstDivideMobile.svg')] h-7  max-sm:h-3  bg-no-repeat bg-center mt-1`
    if (user.order === 1) return `divide bg-[url('/images/leaderboard/secondDivideMobile.svg')] h-7 max-sm:h-3  bg-no-repeat bg-center mt-1`
    if (user.order === 2) return `divide bg-[url('/images/leaderboard/thirdDivideMobile.svg')] h-7 max-sm:h-3  bg-no-repeat bg-center mt-1`
    //if (isSameAddress(address, user)) return `bg-[url('/images/leaderboard/selfDivideMobile.svg')] h-7 bg-no-repeat bg-center mt-1`
    return `divide bg-[url('/images/leaderboard/normalDivideMobile.svg')] h-7 max-sm:h-3  bg-no-repeat bg-center mt-1`
  }
  const context = useContext(UserContext)
  const handleClick = (user:any) => () => {
    context!.setValue(user)
  }
  useEffect(() => {
    if (context?.value===undefined) {
      context!.setValue(firstUser)
    }
  }, [])
  let rankPointsKey = 'WageredSoloQueueRP'
  switch(tabSlug){
    case 'unwagered':
      rankPointsKey = 'UnwageredSoloQueueRP'
    break;
    case 'experience':
      rankPointsKey = 'PlayerExperience'
    break;
    default:
  }
  return <>
    {user?.walletAddress?
    <>
      <div className='table-row h-8 pt-1 pb-2 mb-1' onClick={handleClick(user)}>
        <div className={cn(
          "relative right-[-1rem] icon table-cell w-8 bg-contain  bg-no-repeat bg-center",
          {
            "bg-[url('/images/leaderboard/selfIconMobile.svg')]":user.order>2,
            "bg-[url('/images/leaderboard/firstIconMobile.svg')]":user.order===0,
            "bg-[url('/images/leaderboard/secondIconMobile.svg')]":user.order===1,
            "bg-[url('/images/leaderboard/thirdIconMobile.svg')]":user.order===2,
          }
          )}>
          &nbsp;
        </div>
        <div className='table-cell user-body'>
          <div className='flex flex-row pl-6 align-middle position'>
            <div className='w-20 grow'>{positionByUser(user)}</div>
            <div className="flex-none bg-[url('/images/leaderboard/selfIndicator.svg')] bg-no-repeat bg-right w-20 self-indicator">&nbsp;</div>
            <div className='flex-none pr-3'>YOU</div>
          </div>
          <div className={cn("username flex bg-no-repeat pb-2 pt-1.5 mb-1 h-8 bg-center max-[420px]:bg-contain cursor-pointer",
            {
              "bg-[url('/images/leaderboard/selfLineMobile.svg')]":user.order>2,
              "lg:bg-[url('/images/leaderboard/selfLineDesktop.svg')]":user.order>2,
              "bg-[url('/images/leaderboard/firstLineMobile.svg')]":user.order===0,
              "lg:bg-[url('/images/leaderboard/firstLineDesktop.svg')]":user.order===0,
              "bg-[url('/images/leaderboard/secondLineMobile.svg')]":user.order===1,
              "lg:bg-[url('/images/leaderboard/secondLineDesktop.svg')]":user.order===1,
              "bg-[url('/images/leaderboard/thirdLineMobile.svg')]":user.order===2,
              "lg:bg-[url('/images/leaderboard/thirdLineDesktop.svg')]":user.order===2,
            })}>
            <div className='align-middle max-sm:pl-10 display-name w-52 lg:w-72'>{user?.displayName}</div>
            <div className='vp'>VP</div>
            <div className="divide bg-[url('/images/leaderboard/selfDivideMobile.svg')] h-7 max-sm:h-3 bg-no-repeat bg-center mt-1">&nbsp;</div>
            <div className='pl-2 align-middle rank w-26'>{user?.[rankPointsKey] || 0}</div>
          </div>
        </div>
      </div>
    </>:
      <div className='table-row h-8 pt-1 pb-2 mb-1' onClick={handleClick(user)}>
        <div className={classNameIconByUser(user)}>
          &nbsp;
        </div>
        <div className='table-cell user-body'>
          <div className='w-20 pl-6 text-xs align-middle position'>{positionByUser(user)}</div>
          <div className={classNameBackgroundByUser(user)}>
            <div className='align-middle max-sm:pl-10 w-52 display-name lg:w-72'>{user?.displayName}</div>
            <div className='pr-1 vp'>VP</div>
            <div className={classNameDivideByUser(user)}>&nbsp;</div>
            <div className='pl-2 align-middle rank w-26'>{user?.[rankPointsKey] || 0}</div>
          </div>
        </div>
      </div>
    }
    
  </>
}