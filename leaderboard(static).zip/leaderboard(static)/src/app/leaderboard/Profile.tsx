'use client'

import React, { useContext } from 'react'
import Image from 'next/image'
import { useSearchParams } from 'next/navigation'
import { UserContext } from './context'
import { findTabSlug } from './utils'
const calculateRatio = (win:number, loss:number) => {
  if (win+loss === 0) return <>&nbsp;</>
  return <>{Math.floor((win*100)*10/(win+loss))/10}%</>
}
export default function Profile() {
  const searchParams = useSearchParams()
  const tabSlug = findTabSlug(searchParams.get('tab'))
  const userContext = useContext(UserContext)
  let winKey = 'WageredSoloQueueWins'
  let lossKey = 'WageredSoloQueueLosses'
  switch(tabSlug){
    case 'unwagered':
      winKey = 'UnwageredSoloQueueWins'
      lossKey = 'UnwageredSoloQueueLosses'
    break;
    case 'experience':
      winKey = ''
      lossKey = ''
    break;
    default:
  }  
  return <div className='user-profile lg:w-96 lg:mx-auto'>
    <div className='grid grid-cols-1 gap-1 place-items-center h-28 lg:h-36'>
      <div className="username bg-[url('/images/leaderboard/HeaderMobile.svg')] bg-no-repeat w-72 lg:w-96 bg-center tracking-[.25em] p-1.5 text-center bg-clip-padding text-xl uppercase font-bold">
        {userContext?.value?.displayName}
      </div>
    </div>
    <div className='grid grid-cols-1 gap-1 avatar-wrapper place-items-center'>
      <div className="avatar bg-[url('/images/leaderboard/AvatarWrapper.svg')] bg-no-repeat bg-clip-padding bg-contain p-8 lg:p-10">
        <span className='max-xl:hidden'>
          <Image src="/images/leaderboard/cpfp2-155.png" width={155} height={155} alt="avatar" className='rounded-full' />
        </span>
        <span className='lg:hidden'>
          <Image src="/images/leaderboard/cpfp2-66.png" width={66} height={66} alt="avatar" className='rounded-full' />
        </span>
      </div>
    </div>
    {tabSlug!=='experience' && 
      <div className='info grid grid-cols-5 lg:grid-cols-[8%_30%_30%_30%_2%] gap-4 lg:gap-0 place-items-center my-8'>
        <div>&nbsp;</div>
        <div>
          <div className='text-[#A9E5FF] text-center uppercase text-xs mb-1 tracking-wide lg:tracking-[.25em]'>win</div>
          <div className="icon bg-[url('/images/leaderboard/win.svg')] bg-no-repeat bg-clip-padding bg-contain pt-5 pb-1 px-5 lg:pt-10 lg:px-8 bg-center">&nbsp;</div>
          <div className='text-center lg:text-2xl'>{userContext?.value?.[winKey]||0}</div>
        </div>
        <div>
          <div className='text-[#A9E5FF] text-center uppercase text-xs mb-1 tracking-wide lg:tracking-[.25em]'>loss</div>
          <div className="icon bg-[url('/images/leaderboard/loss.svg')] bg-no-repeat bg-clip-padding bg-contain pt-5 pb-1 px-5 lg:pt-10 lg:px-8 bg-center">&nbsp;</div>
          <div className='text-center lg:text-2xl'>{userContext?.value?.[lossKey]||0}</div>
        </div>
        <div>
          <div className='text-[#A9E5FF] text-center uppercase text-xs mb-1 tracking-wide lg:tracking-[.25em]'>ratio</div>
          <div className="icon bg-[url('/images/leaderboard/ratio.svg')] bg-no-repeat bg-clip-padding bg-contain pt-5 pb-1 px-5 lg:pt-10 lg:px-8 bg-center">&nbsp;</div>
          <div className='text-center lg:text-2xl'>{calculateRatio(userContext?.value?.[winKey]||0, userContext?.value?.[lossKey]||0)}</div>
        </div>
      </div>
    }
  </div>
}