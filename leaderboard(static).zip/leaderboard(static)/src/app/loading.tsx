export default function Loading() {
  // Or a custom loading skeleton component
  return <div className="text-center leading-[20rem] h-[20rem] w-[30rem] sm:w-[23rem]">
    <p className='inline-block leading-[1.5] align-middle'>Loading...</p>
  </div>
}