declare global {
    interface Window {
        ethereum: { t: string},
        web3: { t: string }
    }
}
