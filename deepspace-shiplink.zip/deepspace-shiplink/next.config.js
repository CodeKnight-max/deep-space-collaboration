/** @type {import('next').NextConfig} */

const nextConfig = {
  //output: 'export',
  images: {
    unoptimized: true,
  },
  compiler: {},
  productionBrowserSourceMaps: true,  
  webpack: (config) => {
    config.externals.push("pino-pretty", "lokijs", "encoding");
    return config;
  },
  async redirects() {
    return [
      {
        source: '/',
        destination: '/0',
        permanent: true,
      },
    ]
  },
}

module.exports = nextConfig
