import { Html, Head, Main, NextScript } from 'next/document'

export default function Document({ children }: { children: React.ReactNode }) {
  return (
    <Html lang="en">
      <Head />
      <body>
        <Main />
        <NextScript />
        {children}
        <div className="stars">
          <div className="star"></div>
          <div className="star"></div>
          <div className="star"></div>
          <div className="star"></div>
        </div>
      </body>
    </Html>
  )
}
