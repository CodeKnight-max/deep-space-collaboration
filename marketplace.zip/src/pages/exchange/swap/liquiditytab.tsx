import React from 'react'

export default function LiquidityTab() {
  return (
    <div className="LiquitidyTab">
      <p>Liquidity</p>
    </div>
  )
}
