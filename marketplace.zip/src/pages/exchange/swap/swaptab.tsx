import React from 'react'

export default function SwapTab() {
  return (
    <div className="SwapTab">
      <p>Swap</p>
      {/* First tab content will go here */}
    </div>
  )
}
