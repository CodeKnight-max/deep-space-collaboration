import React from 'react'
import GalacticStoreLayout from '../../layouts/GalacticStoreLayout'
import Sub from './Sub'

const GalacticStore = () => {
  return (
    <div className='goldman-font'>
      <Sub />
    </div>
  )
}

export default GalacticStore

GalacticStore.Layout = GalacticStoreLayout