import React from 'react'
import InventoryLayout from '../../layouts/InventoryLayout'

export default function myequipment() {
  return <div></div>
}

myequipment.Layout = InventoryLayout
