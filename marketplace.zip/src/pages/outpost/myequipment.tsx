import React from 'react'
import OutPostLayout from '../../layouts/OutPostLayout'

export default function myequipment() {
  return <div></div>
}

myequipment.Layout = OutPostLayout
