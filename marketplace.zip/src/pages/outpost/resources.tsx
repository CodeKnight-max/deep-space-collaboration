import React from 'react'
import OutPostLayout from '../../layouts/OutPostLayout'

export default function resources() {
  return <div></div>
}

resources.Layout = OutPostLayout
