import React, { useState, useEffect } from 'react'
import Polling from '../Polling'
import styled from 'styled-components'
import axios from 'axios'
import { SERVICE_API_URL } from '../../constants/index'
import config from '../../config'

const Style = styled.div`
  position: relative;
  .service_status {
    color: rgb(75, 255, 255);
    margin-right: 20px;
  }
`

const Footer = () => {

  const [serverStatus, setServerStatus] = useState('')

  useEffect(() => {
    checkService();
  }, [])

  const checkService = async () => {
    const serviceResponse = await axios.get(SERVICE_API_URL);
    const server_list = serviceResponse?.data?.servers_list
    if (server_list.length > 0) {
      server_list.map((item) => {
        if (config.ENVIRONMENT === item.server_environment.toUpperCase()) {
          setServerStatus(item.global_server_status)
        }
      })
    }
  }

  return (
    <Style>
      <footer className="fixed bottom-0 right-0 items-center justify-end hidden mx-auto text-center md:flex sm:visible w-screenpx-4 text-low-emphesis">
        < div className="flex items-center justify-end px-4 h-14" >
          <div className='service_status goldman-font'>
            <span>Status: {serverStatus} </span>
          </div>
          <Polling />
        </div >
      </footer >
    </Style>

  )
}

export default Footer
