import React, { useState } from 'react';
import styled from 'styled-components';
import { isMobileSafari } from 'react-device-detect'
import cn from 'classnames'
import { FormGroup, Label, Input } from "reactstrap";

const InputStyle = styled.div`
  .option-title {
    font-size: 20px;
    margin-right: 5px;
  }
  input[type="radio"] {
    accent-color: green;
    width: 18px;
    height: 18px;
  }
  .form-control {
    display:block;
    position:relative;
    cursor: pointer;
    input[type="radio"] {
      position: absolute;
      opacity: 0;
      cursor: pointer;
      height: 0;
      width: 0;
    }    
    input:checked ~ .checkmark {
      background-color: transparent;
    }
    input[type="radio"]:checked::before {
      transform: scale(1);
    }   
    .checkmark {
      position: absolute;
      top:5px;
      height: 26px;
      width: 26px;
      background-color: transparent;
      border: 1px solid #a9e2ff;
      border-radius: 50%;
    } 
    input:checked ~ .checkmark:after {
      display: block;
    }
    .checkmark::after {
      content: "";
      position: absolute;
      display: none;
      top: 6px;
      left: 6px;
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: #a9e2ff;
    }
  }
  @media(max-width:535px){
    .option-title{
      font-size:10px;
    }
    .form-control {
      .checkmark {
        top:6px;
        height: 14px;
        width: 14px;
      }
      .checkmark::after {
        top: 3px;
        left: 3px;
        width: 6px;
        height: 6px;
      }
    }
    .isMobileSafari {
      .form-control {
        .checkmark {
          top:7px;
        }
      }
    }
  }
`;

export default function SignUpOption({ title, onChange }) {

  const [maleCheck, setMaleCheck] = useState(false)
  const [femaleCheck, setFemaleCheck] = useState(false)
  const [otherCheck, setOtherCheck] = useState(false)


  const handleChange = (e) => {
    if (e.target.name === 'male') {
      setMaleCheck(true)
      setFemaleCheck(false)
      setOtherCheck(false)
      onChange(e.target.name)
    }
    if (e.target.name === 'female') {
      setMaleCheck(false)
      setFemaleCheck(true)
      setOtherCheck(false)
      onChange(e.target.name)
    }
    if (e.target.name === 'other') {
      setMaleCheck(false)
      setFemaleCheck(false)
      setOtherCheck(true)
      onChange(e.target.name)
    }
  }

  return (
    <InputStyle>
      <div className={cn("pt-4 pb-3 text-center uppercase", { isMobileSafari })}>{title}</div>
      <div className="flex items-center justify-around option-container">
        <FormGroup>
          <Label className='flex items-center form-control'>
            <span className='uppercase option-title text-[#e6e7e8]'>Male</span>
            <Input type="radio" name="male" onChange={handleChange} checked={maleCheck} />
            <span className="checkmark"></span>
          </Label>
        </FormGroup>
        <FormGroup>
          <Label className='flex items-center form-control'>
            <span className='uppercase option-title text-[#e6e7e8]'>Female</span>
            <Input type="radio" name="female" onChange={handleChange} checked={femaleCheck} />
            <span className="checkmark"></span>
          </Label>
        </FormGroup>
        <FormGroup>
          <Label className='flex items-center form-control'>
            <span className='uppercase option-title text-[#e6e7e8]'>Other</span>
            <Input type="radio" name="other" onChange={handleChange} checked={otherCheck} />
            <span className="checkmark"></span>
          </Label>
        </FormGroup>
      </div>
    </InputStyle>
  )
}