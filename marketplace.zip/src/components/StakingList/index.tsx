import React from 'react';
import styled from 'styled-components';
const StakingListStyle = styled.div`
    border-left:5px solid #7F0AA8;
`;
export function StakingList({ data }) {
    return (
        <StakingListStyle>
            <div>
                <div className="flex-1">

                </div>
            </div>
        </StakingListStyle>
    )
}