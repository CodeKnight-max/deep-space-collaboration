import { useCallback, useEffect, useMemo, useState } from 'react'
import { useComplexRewarderContract } from '../../hooks/useContract'

import { BigNumber } from '@ethersproject/bignumber'
import { ChainId } from '@deepspace-game/sdk'
import { Chef } from './enum'
import Fraction from '../../entities/Fraction'
import { getContract } from '../../functions'
import { useActiveWeb3React } from '../../hooks/useActiveWeb3React'
import { useBlockNumber } from '../../state/application/hooks'

const REWARDERS = {
  [ChainId.MAINNET]: 'some',
}

// const useRewarderContract = (farm) => {
//     const { chainId } = useActiveWeb3React()
//     const aclxRewarder = useAlcxRewarderContract()
//     const useComplexRewarderContract = useComplexRewarderContract()
//     // const rewarderContract = await getContract(
//     //     rewarderAddress ? rewarderAddress : undefined,
//     //     ALCX_REWARDER_ABI,
//     //     library!,
//     //     undefined
//     // )
// }

const usePending = (farm) => {
  const [balance, setBalance] = useState<string>('0')

  const { chainId, account, library } = useActiveWeb3React()
  const currentBlockNumber = useBlockNumber()

  const complexRewarder = useComplexRewarderContract(farm?.rewarder?.id)

  return balance
}

export default usePending
