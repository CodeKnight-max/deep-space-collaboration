export interface GSItem {
  id: string;
  name: string;
  listedQty: number;
  soldQty: number;
}

export interface GSListing {
  key: string;
  name: string;
  icon: string;
  config: GSListingConfig
}

export interface GSListingConfig {
  hasConsumables: boolean
  hasNonConsumables: boolean
}

export const defaultGSListingConfig: GSListingConfig = {
  hasConsumables: true,
  hasNonConsumables: true,
}

export const defaultGSConsumablesListingConfig: GSListingConfig = {
  hasConsumables: true,
  hasNonConsumables: false,
}

export const defaultGSNonConsumablesListingConfig: GSListingConfig = {
  hasConsumables: false,
  hasNonConsumables: true,
}