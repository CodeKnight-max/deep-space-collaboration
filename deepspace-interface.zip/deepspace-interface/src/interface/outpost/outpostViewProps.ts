import { OutpostRoute } from '../../app/outpost/menus'

export default interface OutpostViewProps {
  getChildren: (children: OutpostRoute[]) => void
}
