"use client"

import { I18nProvider } from '@lingui/react'
import { i18n } from '@lingui/core'
import React, { useEffect } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import '../bootstrap'

//import * as plurals from 'make-plural'
// import nProgress from "nprogress"
// import "nprogress/nprogress.css"


if (typeof window !== 'undefined' && !!window.ethereum) {
  window.ethereum.autoRefreshOnNetworkChange = false
}

// Router.events.on("routeChangeStart", nProgress.start)
// Router.events.on("routeChangeError", nProgress.done)
// Router.events.on("routeChangeComplete", nProgress.done)
// nProgress.configure({ parent: '.appbar' })


export function LanguagePovider({ children }: { children: React.ReactNode }) {
  //const { locale } = useRouter()
  const locale = 'en'
  const isClient = typeof window !== 'undefined'
  async function load(locale) {
    const messages = await import(`../../locale/${locale}.json`);
    i18n.loadAndActivate({ locale, messages });
  }
  if (!isClient) {
    load(locale)
  }
  const pathname = usePathname()
  const router = useRouter()
  useEffect(() => {
    if (locale !== undefined) {
      load(locale)
    }
    if (pathname === '/') router.push('/outpost/ship-exchange')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return <I18nProvider i18n={i18n} >
    {children}
  </I18nProvider>
}
