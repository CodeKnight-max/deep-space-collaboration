'use client'
import React, { RefObject, useCallback, useEffect, useState } from 'react'
import { useSearchParams } from 'next/navigation';
import cn from 'classnames'
import styled from 'styled-components'
import 'react-loading-skeleton/dist/skeleton.css'
import 'animate.css'
import Scrollbar from "smooth-scrollbar"
import { useActiveWeb3React } from '../../../hooks/useActiveWeb3React'
// import { useDeepspaceContract, useShipsContract } from '../../../hooks'
import ShipCard from '../../../components/ShipCard'
import FilterShips from './components/FilterShips'
import Pagination from '../../../components/Pagination'
import InventoryMobileFooter from './components/Footer'
import { useShipListings, useUserBurnedShips } from '../../../services/graph/hooks/deepspace'
import {
  useFilterBox,
  useFilterData,
  useFirstID,
  useLastID,
  useShipSelects,
  useUpdateFilterData,
  useUpdateFirstID,
  useUpdateLastID
} from '../../../state/others/hooks';
import { useCardCount } from '../../../functions'
import config from '../../../config'
import SkeletonLoading from '../../../components/SkeletonLoading'
import TransparentNavbar from "../../../components/TransparentNavbar"

const pageId = "inventory-ships"

const StyleNftList = styled.div`
`

export default function Ships() {
  const filterData = useFilterData();
  const updateFilterData = useUpdateFilterData();
  const shipSelects = useShipSelects();
  const [pagination, setPagination] = useState(0);
  const [paginationPrevDirection, setPaginationPrevDirection] = useState(1);
  const { account } = useActiveWeb3React()
  const fBox = useFilterBox();
  const [filterStatus, setFilterStatus] = useState(true); // change =>true, dischange =>false
  const updateLastID = useUpdateLastID();
  const updateFirstID = useUpdateFirstID();
  // const deepspaceContract = useDeepspaceContract();
  // const shipContract = useShipsContract();
  const cardCount = useCardCount();
  const [nextID, setNextID] = useState(null);
  const [mintEndTime, setMintEndTime] = useState(null);
  const [mintStartTime, setMintStartTime] = useState(null);
  const [displayTimer, setDisplayTimer] = useState(null);
  const [content, setContent] = useState('');
  const [userOwnedShips, setuserOwnedShips] = useState(0);
  const [userBurnedShips, setUserBurnedShps] = useState(0);

  const firstID = useFirstID();
  const lastID = useLastID();
  const { data: listingData, mutate: userShipsMutate, error: userShipError } = useShipListings(filterStatus, cardCount, paginationPrevDirection, nextID, 'inventory');
  const { data: burnedShipData, mutate: userBurnedShipListing, error: burnedShipError } = useUserBurnedShips();
  const searchParams = useSearchParams()

  const scrollable: RefObject<HTMLDivElement> = React.createRef()

  useEffect(() => {
    if (!!listingData && !!scrollable.current) {
      Scrollbar.init(scrollable.current, { continuousScrolling: false, alwaysShowTracks: true })
    }
  }, [listingData, scrollable])

  useEffect(() => {
    (async () => {
      if (account) {
        /*let d = await shipContract.balanceOf(account);
        setuserOwnedShips(d.toString());*/
      }
    })();
  })
  useEffect(() => {
    if (burnedShipData && burnedShipData.length) {
      setUserBurnedShps(burnedShipData[0].numShips);
    }
  }, [burnedShipData])
  useEffect(() => {
    let routerParams = {};
    if (searchParams.size) {

      for (const [key, value] of searchParams) {
        if (key == 'sortType') routerParams[key] = value
        else {
          routerParams[key] = Number(value)
        }
      }
      updateFilterData(routerParams);
    }
    handleCanMint();
  }, [])

  useEffect(() => {
    setPagination(0);
    setFilterStatus(true);
  }, [shipSelects])

  useEffect(() => {
    updateFirstID(null);
    updateLastID(null);
    setNextID(null);
    setFilterStatus(true);
    setPaginationPrevDirection(1);
    setPagination(0);
  }, [userShipsMutate])

  useEffect(() => {
    updateFirstID(null);
    updateLastID(null);
    setNextID(null);
    setPagination(0);
    setFilterStatus(true);
    setPaginationPrevDirection(1);
  }, [fBox, filterData])

  useEffect(() => {
    if (pagination != 0) setFilterStatus(false);
  }, [pagination]);

  useEffect(() => {
    if (mintEndTime && mintStartTime) {
      let d = new Date();
      const currentTime = d.getTime();
      if (currentTime < mintStartTime) {
        setDisplayTimer(mintStartTime);
        setContent("Genesis Collection Mint Starts In:");
      } else if (mintStartTime <= currentTime && currentTime <= mintEndTime) {
        setDisplayTimer(mintEndTime);

        setContent("Genesis Collection Mint Ends In:");
      } else {
        setDisplayTimer(currentTime);
        setContent("");
      }
    }
  }, [mintStartTime, mintEndTime]);


  const handleCanMint = async () => {
    /*const mintStart = await deepspaceContract.mintStart();
    const mintEnd = await deepspaceContract.mintEnd();

    let d = new Date();
    setMintStartTime(d.setTime(Number(mintStart.toString()) * 1000))
    d = new Date();
    setMintEndTime(d.setTime(Number(mintEnd.toString()) * 1000));*/
  }

  const handlePagination = (dir) => {
    if (!listingData || (listingData.length != shipSelects + 1 && dir > 0)) {
      if (paginationPrevDirection != -1) dir = 0;
    }
    let d = pagination + dir;
    d = Math.max(0, d);
    if (pagination != d && dir != 0) {
      if (dir != paginationPrevDirection) {
        setPaginationPrevDirection(dir);
        setNextID(firstID);
      } else {
        setNextID(lastID);
      }
    }
    setPagination(d);
  }

  const handleTimer = () => {
    let d = new Date();
    const currentTime = d.getTime();

    if (currentTime < mintStartTime) {
      setDisplayTimer(mintStartTime);
      setContent("Genesis Collection Mint Starts In:");
    } else if (mintStartTime <= currentTime && currentTime <= mintEndTime) {
      setDisplayTimer(mintEndTime)
      setContent("Genesis Collection Mint Ends In:");
    } else {
      setDisplayTimer(currentTime);
      setContent("");
    }
  }

  const NFTList = useCallback(() => {
    let shipData = [];
    if (listingData) shipData = [...listingData];

    if (paginationPrevDirection != 1 && listingData) {
      shipData = [...listingData].reverse()
      if (shipData && shipData.length == shipSelects + 1) {
        shipData.shift();
      }
    } else {
      if (shipData && shipData.length == shipSelects + 1) {
        shipData.splice(-1, 1);
      }
    }
    return (
      <>
        <StyleNftList className={cn("inline-flex flex-wrap justify-center px-6 pt-5 w-full", {})}>
          {shipData && filterData && shipData.map((ship, key) => {
            let nft;
            if (filterData.listed == 1) {
              nft = ship['listing'];
            } else {
              nft = ship['ship'];
            }
            return (
              <div className="px-3" key={key}>
                <ShipCard
                  cardType={filterData.listed === 1 ? "my-listing" : "inventory"}
                  key={key}
                  nftData={filterData.listed === 1 ? nft['token'] : nft}
                  price={filterData.listed === 1 ? nft['price'] : '0'}
                  nftFullData={nft}
                />
              </div>
            )
          })}
        </StyleNftList>
        {
          account && !userShipError && listingData == null && (
            <div className='flex flex-wrap justify-center'>
              {

                [...Array(5)].map((item, key) => {
                  return (
                    <div className='px-3' key={key}>
                      <SkeletonLoading />
                    </div>
                  )
                })
              }
            </div>
          )
        }
        {
          (account && listingData?.length == 0) && (
            <div className="flex items-center justify-center w-full">No Matching NFTs</div>
          )
        }
        {
          !account && (
            <div className="flex items-center justify-center w-full">You must connect to view inventory</div>
          )
        }

        {(account && userShipError) && (
          <div className="flex items-center justify-center w-full">NFT searching temporarily unavailable. Please try again later.</div>
        )}
      </>
    )
  }, [listingData, pagination, fBox, cardCount, userShipsMutate])

  if (!config.PAGES.includes(pageId)) {
    return null
  }

  return (
    <>
      <div className='flex flex-col w-full'>
        <TransparentNavbar navType="inventory" />
        <div className="justify-center block mt-2 mb-2 text-sm goldman-font ship-total-status md:hidden">
          {
            account && (
              <div>
                <div>Your Total Ships In Inventory: {userOwnedShips}</div>
                <div>Your Total Ships Burned: {userBurnedShips}</div>
              </div>
            )
          }
        </div>
        {
          mintStartTime && mintEndTime && displayTimer ? (
            <>
              {/* {
                displayTimer == mintStartTime && (
                  <TimerComponent
                    expiryTimestamp={displayTimer}
                    handleTimer={handleTimer}
                    content={content}
                  />
                )
              }
              {
                displayTimer == mintEndTime && (
                  <TimerComponent
                    expiryTimestamp={displayTimer}
                    handleTimer={handleTimer}
                    content={content}
                  />
                )
              } */}
              {
                displayTimer != mintStartTime && displayTimer != mintEndTime && (
                  <div className='mt-2 mb-3 text-center goldman-font'>

                    <div style={{ fontSize: '16px', color: 'cyan' }}>Minting round has ended, watch for future generations.</div>
                    <div className='mt-3 sm:mt-1' style={{ fontSize: '16px', color: 'cyan' }}>Venture to the outpost to purchase a ship.</div>
                  </div>
                )
              }
            </>
          ) : (
            ''
          )
        }


        {/* Mint not supported by contract anymore
        {
          displayTimer && mintEndTime && mintStartTime && (
            <div className="flex justify-center px-5 pt-3 pb-0 md:px-0">
              {
                  displayTimer == mintEndTime && (
                    <MintButton />
                  )
                }
            </div>
          )
        }*/}

        <div className="relative flex flex-wrap justify-center flex-auto w-full px-10 overflow-hidden inventory-filter-section">
          {
            fBox && filterData && (
              <FilterShips
                filterType="inventory"
              />
            )
          }
          <div ref={scrollable}
            className={cn("custom-sync", "h-full", "overflow-auto", {
              'inventory-filter': fBox === true
            })}
            style={{ width: fBox !== true && '100%' }}
          >
            <NFTList />
          </div>
        </div>
        <Pagination handlePagination={handlePagination} data={{ 'cur_pos': pagination }} pageName='inventory' />
      </div>
      <InventoryMobileFooter />
    </>
  )
}