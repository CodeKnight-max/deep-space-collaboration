import type { Metadata } from 'next'
import config from "../../../config"
const configMetaData = () => {
  switch (config.ENVIRONMENT) {
    case 'DEVELOPMENT':
      return 'Dev'
    case 'PRODUCTION':
      return 'DPS'
    default:
      return 'Test'
  }
}

export const metadata: Metadata = {
  title: `DEEPSPACE - Inventory | ${configMetaData()}`,
  description: 'One of the crown jewels of the DEEPSPACE Metaverse is the Outpost. The Outpost is a decentralized exchange hub where you can buy, sell, and trade your ships, cores, and other upgradeable Smart NFTs with fellow explorers. You can use the marketplace to build limited edition ships and acquire other valuable collectible assets. Build up your fleet to explore, harvest, and fight your way through the DEEPSPACE universe!',
  openGraph: {
    title: `DEEPSPACE - Inventory | ${configMetaData()}`,
    description: 'One of the crown jewels of the DEEPSPACE Metaverse is the Outpost. The Outpost is a decentralized exchange hub where you can buy, sell, and trade your ships, cores, and other upgradeable Smart NFTs with fellow explorers. You can use the marketplace to build limited edition ships and acquire other valuable collectible assets. Build up your fleet to explore, harvest, and fight your way through the DEEPSPACE universe!',
    type: 'website',
  },
  twitter: {
    title: `DEEPSPACE - Inventory | ${configMetaData()}`,
    description: 'One of the crown jewels of the DEEPSPACE Metaverse is the Outpost. The Outpost is a decentralized exchange hub where you can buy, sell, and trade your ships, cores, and other upgradeable Smart NFTs with fellow explorers. You can use the marketplace to build limited edition ships and acquire other valuable collectible assets. Build up your fleet to explore, harvest, and fight your way through the DEEPSPACE universe!',
    card: 'summary_large_image',
  },
  viewport: {
    width: 'device-width',
    initialScale: 1,
  },
}

export default function ShipsLayout({
  children
}: {
  children: React.ReactNode
}) {
  return (
    <>
      {children}
    </>
  )
}
