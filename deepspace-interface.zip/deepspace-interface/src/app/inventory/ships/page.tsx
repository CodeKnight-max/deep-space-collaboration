import Ships from "./ships"


export default function ShipsPage() {
  return <Ships />
}