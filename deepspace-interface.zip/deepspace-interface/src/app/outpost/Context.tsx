'use client'

import React, { createContext, useState } from 'react'
interface UserContextProps {
  value: any
  setValue: (value: any) => void
}
export const Context = createContext<UserContextProps | undefined>(undefined)
export const ContextProvider = ({ children }: { children: React.ReactNode }) => {
  const [value, setValue] = useState<UserContextProps>()
  return (
    <Context.Provider value={{ value, setValue }}>
      {children}
    </Context.Provider>
  );
};