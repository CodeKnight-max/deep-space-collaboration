import ship_exchange from '../../asset/image/icons/ship_exchange.svg'
import galactic_store from '../../asset/image/icons/galactic_store.svg'
import resource_swap from '../../asset/image/icons/resource_swap.svg'
import technology from '../../asset/image/icons/technology.svg'
import { getChildRoutes } from './galactic-store/menus'

export interface OutpostRoute {
  key: string
  name: string
  path: string
  icon: string
  hasChildren?: boolean
  children?: OutpostRoute[]
}

const routes: OutpostRoute[] = [
  {
    key: 'ship-exchange',
    name: 'Ship Exchange',
    path: '/outpost/ship-exchange',
    icon: ship_exchange,
    hasChildren: true,
    children: [
      {
        key: 'activity',
        name: 'Activity',
        icon: technology,
        path: `/outpost/ship-exchange/activity`,
      },
    ],
  },
  {
    key: 'galactic-store',
    name: 'Galactic Store',
    path: '/outpost/galactic-store',
    icon: galactic_store,
    hasChildren: true,
    children: getChildRoutes(),
  },
  {
    key: 'resource-exchange',
    name: 'Resource Exchange',
    path: '/outpost/resource-exchange',
    icon: resource_swap,
  },
]

export default routes
