export default function GalacticStore(): JSX.Element {
  return (
    <div className="flex items-center justify-center w-full h-full">
      <span className="mb-40 text-center">TODO:<br />Design & Implement Galactic Store's home screen</span>
    </div>
  )
}