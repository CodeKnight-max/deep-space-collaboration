import Store from "./store"


export default function GalacticStorePage() {
  return <Store />
}