import chemicals from '../../../asset/image/icons/chemicals.svg'
import consumer from '../../../asset/image/icons/consumer.svg'
import metal from '../../../asset/image/icons/metal.svg'
import mineral from '../../../asset/image/icons/mineral.svg'
import technology from '../../../asset/image/icons/technology.svg'
import weapon from '../../../asset/image/icons/weapon.svg'
import cores from '../../../asset/image/icons/cores.svg'
import {
  defaultGSConsumablesListingConfig as consList,
  defaultGSListingConfig as defaultList,
  defaultGSNonConsumablesListingConfig as nonConsList,
  GSListing,
} from '../../../interface/galactic-store'
import { OutpostRoute } from '../menus'

const parentRouteKey = 'galactic-store'
const baseUrl = `/outpost/${parentRouteKey}`

export const listings: GSListing[] = [
  { key: 'chemicals', name: 'Chemicals', icon: chemicals, config: defaultList },
  { key: 'consumer', name: 'Consumer Items', icon: consumer, config: defaultList },
  { key: 'cores', name: 'Cores', icon: cores, config: consList },
  { key: 'metals', name: 'Metals', icon: metal, config: nonConsList },
  { key: 'minerals', name: 'Minerals', icon: mineral, config: consList },
  { key: 'technology', name: 'Technology', icon: technology, config: nonConsList },
  { key: 'weapons', name: 'Weapons', icon: weapon, config: defaultList },
]

export const getChildRoutes = (): OutpostRoute[] =>
  listings.map((l) => ({
    key: l.key,
    name: l.name,
    icon: l.icon,
    path: `${baseUrl}/${l.key}`,
  }))
