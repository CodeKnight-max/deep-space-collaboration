import Store from "./store"


export default function GalacticStoreTypePage({ params }: { params: { slug: string } }) {
  return <Store type={params.slug} />
}