'use client'

import { useRouter } from "next/navigation";
import React, { RefObject, useEffect, useState } from "react";
import { ToastContainer } from "react-toastr";
import getBreakpoints from "../../../../services/responsive";
import { consumableItemsData, nonConsumableItemsData } from "../../../../constants/galactic-store/items";
import Scrollbar from "smooth-scrollbar";
//import { useDPSToken } from "../../../hooks/Tokens";
import useActiveWeb3React from "../../../../hooks/useActiveWeb3React";
import inventory from "../../../../asset/image/icons/inventory.svg"
import sort from "../../../../asset/image/icons/sort.svg"
import filter from "../../../../asset/image/icons/filter.svg"
import { getGalacticItems } from "../../../../services/graph/hooks/deepspace";
import {
  GSItem,
} from "../../../../interface/galactic-store";
import GalacticStoreModal from "../../../../components/Modal/GalacticStoreModal";
import FiltersDrawer from "../../../../components/GalacticStore/FiltersDrawer";
import SortDrawer from "../../../../components/GalacticStore/SortDrawer";
import Divider from "../../../../components/Core/Divider";
import ButtonAlt from "../../../../components/Core/ButtonAlt/ButtonAlt";
import ItemTable from "../../../../components/GalacticStore/ItemTable";
import ItemPanel from "../../../../components/GalacticStore/ItemPanel";
import IconWrapper from "../../../../components/Layout/IconWrapper";
import { listings } from "../menus";

export default function GalacticStore({ type }: { type: string }) {
  const breakpoints = getBreakpoints()
  const scrollable: RefObject<HTMLDivElement> = React.createRef()
  const toastContainer: RefObject<ToastContainer> = React.createRef()

  const [selectedItem, setSelectedItem] = useState(null)
  const [activePanelIdx, setActivePanelIdx] = useState(null)
  const [isFilterDrawerActive, setIsFilterDrawerActive] = useState(false)
  const [isSortDrawerActive, setIsSortDrawerActive] = useState(false)
  const [showConsumables, setShowConsumables] = useState(true)
  const [consumableItems, setConsumableItems] = useState([])
  const [nonConsumableItems, setNonConsumableItems] = useState([])

  const listing = listings.find(l => l.key === type)
  const { data: galacticItems } = getGalacticItems()
  const { account } = useActiveWeb3React()

  useEffect(() => {
    if (galacticItems) {
      setConsumableItems(galacticItems?.consumables ?? [])
      setNonConsumableItems(galacticItems?.nonConsumables ?? [])
    }
  }, [galacticItems])

  useEffect(() => {
    if (listing) {
      setShowConsumables(listing.config?.hasConsumables)
      setIsFilterDrawerActive(false)
      setIsSortDrawerActive(false)
    }
  }, [listing])

  useEffect(() => {
    if (!!scrollable.current) {
      Scrollbar.init(scrollable.current, { continuousScrolling: false, alwaysShowTracks: true })
    }
  }, [scrollable])

  const items = () => showConsumables ? consumableItems : nonConsumableItems
  const data = () => showConsumables ? consumableItemsData : nonConsumableItemsData

  // TODO: Handle not found. GSITem | undefined
  const getItemData = (itemId: string): GSItem => {
    return data().find(i => i.id === itemId)
  }

  const showToast = (status) => {
    if (toastContainer.current) {
      if (status === 'accountDisconnect') toastContainer.current.error("Please connect wallet", "Error");
      if (status === 'lessBalance') toastContainer.current.error("Balance is not enough.", "Error");
      if (status === 'approveSuccess') toastContainer.current.success(`Approve success. Please click confirm.`, 'Success');
    }
  }

  const onBuyClick = (item: any) => {
    if (account) {
      setSelectedItem(item)
    } else {
      showToast('accountDisconnect')
    }
  }

  if (!listing) return (
    <div className="flex items-center justify-center w-full h-full">
      <span className="mb-40 text-center">TODO:<br />Design & Implement Galactic Store's home screen</span>
    </div>
  )

  return (
    <div>
      <ToastContainer ref={toastContainer} className="toast-top-right" style={{ zIndex: '100000' }} />
      {account && selectedItem && (
        <GalacticStoreModal show onClose={() =>
          setSelectedItem(null)} storeItem={selectedItem} showToastr={showToast} />
      )}

      <FiltersDrawer active={isFilterDrawerActive} hasConsumables={listing.config.hasConsumables}
        hasNonConsumables={listing.config.hasNonConsumables}
        actions={{ itemType: setShowConsumables }}
        onClose={() => setIsFilterDrawerActive(false)} />
      <SortDrawer active={isSortDrawerActive} onClose={() => setIsSortDrawerActive(false)} />

      <div className={`flex pt-10 ${breakpoints.lg ? 'px-14 pb-16' : 'p-6'}`}>
        <IconWrapper className={`mr-2 ${breakpoints.lg ? 'w-28 h-24' : 'w-16 h-16'}`}
          icon={listing.icon}
          size={breakpoints.lg ? 45 : 30} />

        <div className="flex flex-col flex-auto h-full pt-3">
          <div className="flex flex-col flex-auto">
            <h1 className={`flex-col uppercase pb-1 ml-3 ${breakpoints.lg ? 'text-3xl' : 'text-xl'}`}>
              {listing.name}
            </h1>
            <Divider />
          </div>

          <div className="flex items-center justify-end flex-auto pt-3">
            <ButtonAlt icon={inventory} text="Inventory" className={breakpoints.lg ? 'text-base' : 'text-xs'} accent />
          </div>
        </div>
      </div>

      <div className="relative">
        <div className={`${breakpoints.lg ? 'absolute' : 'pb-3'} flex px-6`} style={{ zIndex: '1' }}>
          <ButtonAlt icon={sort} text={breakpoints.lg ? 'Sort' : null} className="mr-3"
            onClick={() => setIsSortDrawerActive(true)} secondary />

          <ButtonAlt icon={filter} text={breakpoints.lg ? 'Filter' : null}
            onClick={() => setIsFilterDrawerActive(true)} secondary />
        </div>
      </div>

      {breakpoints.lg && <div ref={scrollable} className="flex-auto overflow-y-auto">
        <ItemTable items={items()} itemsData={data()} onClick={onBuyClick} />
      </div>}

      {!breakpoints.lg && <div ref={scrollable}
        className={`flex-auto px-4 pb-2 overflow-y-auto ${breakpoints.lg ? 'text-lg' : ''}`}>
        <div>
          {items().map((item, index) => (
            <ItemPanel active={activePanelIdx === index} key={index}
              item={item} itemData={getItemData(item.id)}
              onHeaderClick={() => setActivePanelIdx(activePanelIdx !== index ? index : null)}
              onBuyClick={onBuyClick} />
          ))}
        </div>
      </div>}
    </div>)
}
