import StyleWrapper from './StyleWrapper'
import DpsToResource from "./components/DpsToResource"


export default function ResourceExchange(): JSX.Element {

  return (
    <StyleWrapper>
      <div className='style_title'>
        GALACTIC RESOURCE EXCHANGE
      </div>
      <div className="dps-resource">
        <DpsToResource />
      </div>
    </StyleWrapper>
  )
}