import ShipExchangeList from "./components/OutPostList"


export default function ShipExchange(): JSX.Element {
  return <ShipExchangeList />
}