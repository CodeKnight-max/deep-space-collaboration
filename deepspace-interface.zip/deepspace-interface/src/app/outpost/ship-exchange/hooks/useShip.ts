import { useBalance, useContractRead } from 'wagmi'
import configData from '../../../../config'
import DPS_Ships_ABI from '../../../../constants/abis/DPS_Ships.json'

// export function useShipBalanceOf() {
//   const address = configData.MARKETPLACE_ADDRESS
//   const token = configData.SHIPS_ADDRESS
//   const { data, isError, isLoading } = useBalance({ address, token })
//   return {
//     balance: data,
//     isLoading,
//     isError,
//   }
// }
export function useShipMarketplaceBalanceOf() {
  const ownerAddress = configData.MARKETPLACE_ADDRESS
  const address = configData.SHIPS_ADDRESS
  return useContractRead({
    address: address as `0x${string}`,
    abi: DPS_Ships_ABI,
    functionName: 'balanceOf',
    args: [ownerAddress],
    watch: true,
    cacheTime: 60_000,
    enabled: Boolean(ownerAddress),
  })
}
