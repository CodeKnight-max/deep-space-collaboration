import {
  useContractWrite,
  useContractRead,
  usePrepareContractWrite,
  useAccount,
  useWaitForTransaction,
  useBalance,
} from 'wagmi'
import ERC20_ABI from '../../../../constants/abis/erc20.json'
import DPS_APP_ABI from '../../../../constants/abis/DPS_App.json'
import configData from '../../../../config'
import { useShipCard } from '../../../../state/others/hooks'

export function useDPSTokenBalanceOf() {
  const token = configData.DPS_TOKEN_ADDRESS
  const { address } = useAccount()
  const { data, isError, isLoading } = useBalance({ address, token })
  return {
    balance: data,
    isLoading,
    isError,
  }
}
export function useApproveCallback() {
  const { data } = useGetApprovalDPSToken()
  const shipCard = useShipCard()
  const price = shipCard.price ? BigInt(shipCard.price) : 0n
  const senderAddress = configData.DPS_APP_ADDRESS
  const { config } = usePrepareContractWrite({
    address: configData.DPS_TOKEN_ADDRESS,
    abi: ERC20_ABI,
    functionName: 'approve',
    args: [senderAddress, price],
    enabled: true,
  })
  const { data: purchase, write, writeAsync } = useContractWrite(config)

  const { isLoading, isSuccess } = useWaitForTransaction({
    hash: purchase?.hash,
  })

  return {
    allowance: typeof data === 'bigint' ? data : 0n,
    write,
    approve: writeAsync,
    isTransactionSuccess: isSuccess,
    isTransactionLoading: isLoading,
  }
}
export function usePurchaseCallback() {
  const shipCard = useShipCard()
  const price = shipCard.price ? BigInt(shipCard.price) : 0n
  const { config } = usePrepareContractWrite({
    address: configData.DPS_APP_ADDRESS,
    abi: DPS_APP_ABI,
    functionName: 'purchaseNFT',
    args: [shipCard.tokenAddress, shipCard.token.tokenId, price],
    enabled: true,
  })
  const { data, write, writeAsync } = useContractWrite(config)

  const {
    data: transaction,
    isLoading,
    isSuccess,
  } = useWaitForTransaction({
    hash: data?.hash,
  })
  return {
    write,
    isTransactionSuccess: isSuccess,
    isTransactionLoading: isLoading,
    transaction,
    purchase: writeAsync,
  }
}

export const useGetApprovalDPSToken = () => {
  const senderAddress = configData.DPS_APP_ADDRESS
  const address = configData.DPS_TOKEN_ADDRESS
  const { address: ownerAddress } = useAccount()
  return useContractRead({
    address: address as `0x${string}`,
    abi: ERC20_ABI,
    functionName: 'allowance',
    args: [ownerAddress, senderAddress],
    watch: true,
    cacheTime: 60_000,
    enabled: Boolean(senderAddress && ownerAddress),
  })
}
