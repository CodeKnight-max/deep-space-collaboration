import ShipExchangeActivity from "./activity";

export default function Activity(): JSX.Element {
  return <ShipExchangeActivity />
}