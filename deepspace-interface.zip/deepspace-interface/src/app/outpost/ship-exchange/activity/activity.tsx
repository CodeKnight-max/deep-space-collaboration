"use client"
import React, { RefObject, useEffect, useState } from "react";
import styled from 'styled-components'
import SoldChart from "./SolidChart";
import ShipExchangeFilters from "../components/ShipExchangeFilters";
import Divider from "../../../../components/Core/Divider";
import ButtonAlt from "../../../../components/Core/ButtonAlt/ButtonAlt";
import getBreakpoints from "../../../../services/responsive";
import config from "../../../../config";
import { useActiveWeb3React } from "../../../../hooks";
import filter from "../../../../asset/image/icons/filter.svg";
import { FILTER_DATA } from "../../../../constants";
import { AiOutlineLeft, AiOutlineRight } from "react-icons/ai";
import {
  useFilterBox,
  useFilterData,
  useFirstID,
  useLastID,
  useShipSelects,
  useUpdateFirstID,
  useUpdateLastID
} from "../../../../state/others/hooks";
import { useShipListings } from "../../../../services/graph/hooks/deepspace";
import SoldShipCardDeskTop from "../../../../components/SoldShipCardDeskTop";
import SoldShipCardMobile from "../../../../components/SoldShipCardMobile";
import Scrollbar from "smooth-scrollbar";
import ship_exchange from "../../../../asset/image/icons/ship_exchange.svg";
import IconWrapper from "../../../../components/Layout/IconWrapper";
import { useShipMarketplaceBalanceOf } from "../hooks/useShip"

export default function ShipExchangeActivity(): JSX.Element {
  const breakpoints = getBreakpoints();
  const scrollable: RefObject<HTMLDivElement> = React.createRef()
  const { data: shipBalance } = useShipMarketplaceBalanceOf()
  const filterData = useFilterData();
  const { account } = useActiveWeb3React();
  const shipSelects = useShipSelects();
  const fBox = useFilterBox();
  const [nextID, setNextID] = useState(null);
  const firstID = useFirstID();
  const lastID = useLastID();

  const [isFilterDrawerActive, setIsFilterDrawerActive] = useState(false)
  const [listedShipsCount, setListedShipsCount] = useState(0);
  const [pagination, setPagination] = useState(0);
  const [filterStatus, setFilterStatus] = useState(true); // change =>true, dischange =>false
  const [listingData, setListingData] = useState(null);
  const [paginationPrevDirection, setPaginationPrevDirection] = useState(1);
  const queryType = filterData.newListing ? (filterData.myListing ? 'outpostMyListing' : 'outpostNewListing') : (filterData.mySale ? 'outpostMySale' : 'outpostSale');
  const { data: fetchData, mutate: shipListingsMutate, error } = useShipListings(filterStatus, shipSelects, paginationPrevDirection, nextID, queryType);

  useEffect(() => {
    if (!!listingData && !!scrollable.current) {
      Scrollbar.init(scrollable.current, { continuousScrolling: false, alwaysShowTracks: true })
    }
  }, [listingData, scrollable])

  useEffect(() => {
    if (fetchData) {
      let shipData = [];
      if (fetchData) shipData = [...fetchData];

      if (paginationPrevDirection != 1 && fetchData) {
        shipData = [...fetchData].reverse()
        if (shipData && shipData.length == shipSelects + 1) {
          shipData.shift();
        }
      } else {
        if (shipData && shipData.length == shipSelects + 1) {
          shipData.splice(-1, 1);
        }
      }
      setListingData(shipData);
    }
  }, [fetchData, shipListingsMutate])

  useEffect(() => {
    setFilterStatus(true);
    setPaginationPrevDirection(1);
    setPagination(0);
  }, [shipListingsMutate])

  useEffect(() => {
    setFilterStatus(true);
    setPagination(0);
    setPaginationPrevDirection(1);
  }, [filterData, fBox])

  useEffect(() => {
    if (pagination != 0) setFilterStatus(false);
  }, [pagination]);

  const handlePagination = (dir) => {
    if (!fetchData || (fetchData.length != shipSelects + 1 && dir > 0)) {
      if (paginationPrevDirection != -1) dir = 0;
    }
    let d = pagination + dir;
    d = Math.max(0, d);
    if (pagination != d && dir != 0) {
      if (dir != paginationPrevDirection) {
        setPaginationPrevDirection(dir);
        setNextID(firstID);
      } else {
        setNextID(lastID);
      }
    }
    setPagination(d);
  }

  useEffect(() => {
    setListedShipsCount(Number(shipBalance))
  }, [shipBalance])

  return (
    <Style className="flex flex-col h-full">
      <ShipExchangeFilters active={isFilterDrawerActive}
        isActivityView={true}
        onClose={() => setIsFilterDrawerActive(false)} />

      <div className={`flex pt-10 ${breakpoints.lg ? 'px-14' : 'p-10'}`}>
        <IconWrapper className={`mr-2 ${breakpoints.lg ? 'w-28 h-24' : 'w-16 h-16'}`}
          icon={ship_exchange}
          size={breakpoints.lg ? 45 : 30} />

        <div className="flex flex-col flex-auto h-full pt-3">
          <div className="flex flex-col flex-auto">
            <h1 className={`flex-col uppercase pb-1 ml-3 ${breakpoints.lg ? 'text-3xl' : 'text-xl'}`}>
              {`${breakpoints.lg ? 'Ship Exchange' : ''} Activity`}
            </h1>
            <Divider />
          </div>

          <div className={`flex justify-between flex-auto pt-3 ${breakpoints.lg ? 'px-5' : 'pl-2'}`}>
            <span className="text-sm font-normal leading-none">Total Ships for Sale: {listedShipsCount}</span>
          </div>
        </div>
      </div>

      <div className={`flex justify-end mb-2 ${breakpoints.lg ? 'pr-20 pl-48' : 'px-3'}`}>
        <SoldChart />
      </div>

      <div className="flex justify-between px-6 mb-3">
        <ButtonAlt icon={filter} text={breakpoints.lg ? 'Filter' : null}
          onClick={() => setIsFilterDrawerActive(true)} secondary
          active={JSON.stringify(filterData) != JSON.stringify(FILTER_DATA)} />

        <div className="flex items-center">
          <ButtonAlt className="mr-3" icon={AiOutlineLeft}
            onClick={() => handlePagination(-1)} secondary accent />
          Page {pagination + 1}
          <ButtonAlt className="ml-3" icon={AiOutlineRight}
            onClick={() => handlePagination(1)} secondary accent />
        </div>
      </div>

      <Divider />
      <div ref={scrollable} className='flex justify-center pr-5 ship-list-section'>
        {
          listingData && listingData.length ? (
            <>
              <div className='w-full pl-3 mb-12 desktop-section'>
                <SoldShipCardDeskTop listingData={listingData} filterType={queryType} />
              </div>
              <div className='w-full mb-12 mobile-section'>
                <SoldShipCardMobile listingData={listingData} filterType={queryType} />
              </div>
            </>
          ) : ('')
        }
        {
          (!listingData && !error) ? (
            <div className='w-full my-10 text-center'>Loading...</div>
          ) : ('')
        }
        {

          (listingData && listingData.length == 0) ? (
            <div className='w-full my-10 text-center'>No Matching Data</div>
          ) : ('')
        }
        {
          (error && !listingData && account) ? (
            <div className='w-full my-10 text-center'>Genesis Server Error. Please wait a while</div>
          ) : ('')
        }
        {

          (error && !listingData && !account && queryType === 'outpostMySale') ? (
            <div className='w-full my-10 text-center'>Please connect wallet to view "My Sales"</div>
          ) : ('')
        }
      </div>
    </Style>
  )
}

const Style = styled.div`
  .mobile-section{
    display:none;
  }
  @media(max-width:1143px){
    .ship-list-section{
      display:block;
    }
    .ship-filter-section{
      width:100%;
    }
  }
  @media(max-width:992px){
    .desktop-section{
      display:none;
    }
    .mobile-section{
      display:block;
    }
  }
`
