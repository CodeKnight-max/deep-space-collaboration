'use client'
import React, { useEffect, useState } from 'react'
import { formatUnits } from 'viem'
import { useAccount } from 'wagmi'
import ShipCard from '../../../../../components/ShipCard'
import { useShipCard } from '../../../../../state/others/hooks';
import { useTransactionAdder } from '../../../../../state/transactions/hooks'
import { PAYMENT_DECIMALS } from '../../../../../constants'
import { formatNumberWithGrouping } from '../../../../../functions';
import { useApproveCallback, usePurchaseCallback } from '../../hooks/useDeepspace'

const LeftShipCard = ({ shipCardType }) => {
  const shipCard = useShipCard()
  return <div className="px-2">
    <ShipCard
      modaltype={shipCardType}
      nftData={shipCard['token'] ? shipCard['token'] : shipCard}
      price={''}
      nftFullData={shipCard['token'] ? shipCard['token'] : shipCard}
    />
  </div>
}
const SubTitle = ({ title }) => {
  return (
    <div className='sm:mb-8 sm:pb-2'>
      <span className="font-extrabold goldman-font" style={{ color: '#00ffff' }}>
        {title}
      </span>
    </div>
  )
}
const SubQuestion = ({ children }: { children: React.ReactNode }) => {
  return <div className='pb-2 text-left sm:mb-8' >
    <span>
      {children}
    </span>
  </div>
}
const ConfirmButton = ({ onClose, setLoadSpinner }) => {
  const { isConnected } = useAccount()
  const addTransaction = useTransactionAdder()
  const shipCard = useShipCard()
  const { purchase, transaction, isTransactionSuccess } = usePurchaseCallback()
  useEffect(() => {
    if (isTransactionSuccess) {
      addTransaction(transaction, {
        summary: `Purchase Ship #` + shipCard.token.tokenId,
      })
      setLoadSpinner(0);
      onClose()
    }
  }, [isTransactionSuccess])
  const handleConfirm = async () => {
    setLoadSpinner(1);
    try {
      // const estimateGas = await deepspaceContract.estimateGas.purchaseNFT(shipCard.tokenAddress, shipCard.token.tokenId, price)
      // const tx = await deepspaceContract.write.purchaseNFT(shipCard.tokenAddress, shipCard.token.tokenId, price)
      await purchase?.()
      setLoadSpinner(2);
    } catch (error) {
      console.error(error)
      setLoadSpinner(3);
    }
  }

  return (
    <button
      onClick={handleConfirm}
      className='px-4 py-1 ml-2 font-bold text-black bg-white glass-button'
      style={!isConnected ? { cursor: "not-allowed", 'pointerEvents': 'all' } : {}}
      disabled={!isConnected}
    >
      <span className="glass-button-before"></span>
      <span>Confirm</span>
    </button>
  )
}
const Actions = ({ onClose, setLoadSpinner, showToastr }) => {
  const { isConnected } = useAccount()
  const [approveStart, setApproveStart] = useState(false)
  const shipCard = useShipCard()
  const price = shipCard.price ? BigInt(shipCard.price) : 0n
  const { allowance, approve, isTransactionSuccess } = useApproveCallback()
  console.log(allowance, '--allowance--')
  useEffect(() => {
    if (showToastr && allowance !== 0n && approveStart) {
      setApproveStart(false);
      showToastr('approveSuccess');
    }
  }, [allowance])

  useEffect(() => {
    if (allowance === 0n && isConnected) {
      showToastr('aprroveReady')
    }
  }, [])
  const handleCloseClick = (e) => {
    e.preventDefault()
    onClose()
  }

  const handleApprove = async () => {
    setLoadSpinner(1);
    try {
      await approve?.()
      setLoadSpinner(2)
    } catch (e) {
      console.log(e, "Approve Error");
      setLoadSpinner(3)
    }
    setApproveStart(true)
  }
  useEffect(() => {
    if (isTransactionSuccess) {
      setLoadSpinner(0)
    }
  }, [isTransactionSuccess])

  return (
    <>
      <button onClick={handleCloseClick} className="px-4 py-1 font-bold text-black bg-white glass-button">
        <span className="glass-button-before"></span>
        <span>Cancel</span>
      </button>
      {allowance >= price ? (
        <ConfirmButton onClose={onClose} setLoadSpinner={setLoadSpinner} />
      ) : (
        <button
          onClick={handleApprove}
          className='px-4 py-1 ml-2 font-bold text-black bg-white glass-button'
          style={!isConnected ? { cursor: "not-allowed", 'pointerEvents': 'all' } : {}}
          disabled={!approve}
        >
          <span className="glass-button-before"></span>
          <span>Approve</span>
        </button>
      )}
    </>
  )
}
//shipCardType encapsulate
export default function Buy({ onClose, showToastr, setLoadSpinner }) {
  const shipCardType = 'buy-ship'
  const shipCard = useShipCard()
  const price = shipCard.price ? BigInt(shipCard.price) : 0n
  const formattedPrice = price ? formatNumberWithGrouping(formatUnits(price, PAYMENT_DECIMALS).toString()) : ''
  return <>
    <LeftShipCard shipCardType={shipCardType} />
    <div className='flex flex-col items-center justify-start w-full px-2 text-base text-white'>
      <SubTitle title='Buy Ship' />
      <SubQuestion>
        Are you sure you want <br /> to buy this ship for {formattedPrice} DPS?
      </SubQuestion>
      <div className='flex flex-row justify-center w-full'>
        <Actions onClose={onClose} showToastr={showToastr} setLoadSpinner={setLoadSpinner} />
      </div>
    </div>
  </>
}
