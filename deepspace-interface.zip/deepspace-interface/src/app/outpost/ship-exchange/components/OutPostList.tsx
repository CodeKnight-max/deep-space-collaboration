"use client"
import React, { RefObject, useCallback, useEffect, useState } from "react";
import Scrollbar from "smooth-scrollbar";
import styled from "styled-components";
import Link from "next/link";
import {
  useFilterBox,
  useFilterData,
  useFirstID,
  useLastID,
  useShipSelects,
} from "../../../../state/others/hooks";
import { useShipListings } from "../../../../services/graph/hooks/deepspace";
import ShipCard from "../../../../components/ShipCard";
import SkeletonLoading from "../../../../components/SkeletonLoading";
import Divider from "../../../../components/Core/Divider";
import ButtonAlt from "../../../../components/Core/ButtonAlt/ButtonAlt";
import getBreakpoints from "../../../../services/responsive";
import filter from "../../../../asset/image/icons/filter.svg";
import inventory from "../../../../asset/image/icons/inventory.svg";
import ShipExchangeFilters from "./ShipExchangeFilters";
import { FILTER_DATA } from "../../../../constants";
import { AiOutlineLeft, AiOutlineRight } from "react-icons/ai";
import config from "../../../../config";
import { useShipsContract } from "../../../../hooks";
import IconWrapper from "../../../../components/Layout/IconWrapper";
import ship_exchange from "../../../../asset/image/icons/ship_exchange.svg";

export default function OutPostList() {
  const [pagination, setPagination] = useState(0);
  const [paginationPrevDirection, setPaginationPrevDirection] = useState(1);
  const [filterStatus, setFilterStatus] = useState(true); // change =>true, dischange =>false
  const fBox = useFilterBox();
  const [nextID, setNextID] = useState(null);
  const firstID = useFirstID();
  const lastID = useLastID();
  const shipSelects = useShipSelects();
  const shipContract = useShipsContract();
  const filterData = useFilterData();
  const breakpoints = getBreakpoints();
  const {
    data: listingData,
    mutate: shipListingsMutate,
    error
  } = useShipListings(filterStatus, shipSelects, paginationPrevDirection, nextID, 'outpost');

  useEffect(() => {
    setFilterStatus(true);
    setPaginationPrevDirection(1);
    setPagination(0);
  }, [shipListingsMutate])

  useEffect(() => {
    setFilterStatus(true);
    setPagination(0);
    setPaginationPrevDirection(1);
  }, [filterData, fBox])

  useEffect(() => {
    if (pagination != 0) setFilterStatus(false);
  }, [pagination]);

  const handlePagination = (dir) => {
    if (!listingData || (listingData.length != shipSelects + 1 && dir > 0)) {
      if (paginationPrevDirection != -1) dir = 0;
    }
    let d = pagination + dir;
    d = Math.max(0, d);
    if (pagination != d && dir != 0) {
      if (dir != paginationPrevDirection) {
        setPaginationPrevDirection(dir);
        setNextID(firstID);
      } else {
        setNextID(lastID);
      }

    }
    setPagination(d);
  }

  const OutPostList = useCallback(() => {
    let shipData = [];
    const scrollable: RefObject<HTMLDivElement> = React.createRef()
    const [isFilterDrawerActive, setIsFilterDrawerActive] = useState(false)

    useEffect(() => {
      if (!!shipData && !!scrollable.current) {
        Scrollbar.init(scrollable.current, { continuousScrolling: false, alwaysShowTracks: true })
      }
    }, [shipData, scrollable])

    if (listingData) shipData = [...listingData];

    if (paginationPrevDirection != 1 && listingData) {
      shipData = [...listingData].reverse()
      if (shipData && shipData.length == shipSelects + 1) {
        shipData.shift();
      }
    } else {
      if (shipData && shipData.length == shipSelects + 1) {
        shipData.splice(-1, 1);
      }
    }

    const [listedShipsCount, setListedShipsCount] = useState<BigInt>(0n);
    useEffect(() => {
      (async () => {
        if (shipContract?.read.balanceOf) {
          let e = await shipContract.read.balanceOf([config.MARKETPLACE_ADDRESS]);
          if (typeof e === 'bigint') {
            setListedShipsCount(e)
          }
        }
      })();
    })

    return (
      <Style className="flex flex-col h-full">
        <ShipExchangeFilters active={isFilterDrawerActive}
          onClose={() => setIsFilterDrawerActive(false)} />

        <div className={`flex pt-10 ${breakpoints.lg ? 'px-14 pb-16' : 'p-6'}`}>
          <IconWrapper className={`mr-2 ${breakpoints.lg ? 'w-28 h-24' : 'w-16 h-16'}`}
            icon={ship_exchange}
            size={breakpoints.lg ? 45 : 30}
          />

          <div className="flex flex-col flex-auto h-full pt-3">
            <div className="flex flex-col flex-auto">
              <h1 className={`flex-col uppercase pb-1 ml-3 ${breakpoints.lg ? 'text-3xl' : 'text-xl'}`}>
                Ship Exchange
              </h1>
              {/* TODO: Make header below divider align with navigation's */}
              <Divider />
            </div>

            <div className="flex justify-between flex-auto px-5 pt-3">
              <span className="text-sm font-normal leading-none">Total Ships for Sale: {listedShipsCount.toLocaleString()}</span>

              <Link href="/inventory/ships" passHref legacyBehavior>
                <ButtonAlt icon={inventory} text="Inventory" className={breakpoints.lg ? 'text-base' : 'text-xs'} accent />
              </Link>
            </div>
          </div>
        </div>

        <div className="flex justify-between px-6 mb-3">
          <ButtonAlt icon={filter} text={breakpoints.lg ? 'Filter' : null}
            onClick={() => setIsFilterDrawerActive(true)} secondary
            active={JSON.stringify(filterData) != JSON.stringify(FILTER_DATA)} />

          <div className="flex items-center">
            <ButtonAlt className="mr-3" icon={AiOutlineLeft}
              onClick={() => handlePagination(-1)} secondary accent />
            Page {pagination + 1}
            <ButtonAlt className="ml-3" icon={AiOutlineRight}
              onClick={() => handlePagination(1)} secondary accent />
          </div>
        </div>

        <Divider />
        <div ref={scrollable} className="w-full px-6 pt-5 overflow-auto ship-list">
          {shipData && filterData && shipData.map((listing, key) => {
            listing = listing['listing'];
            const nft = listing['token'];
            return (
              <div key={key}>
                <ShipCard
                  cardType="shipsoutpost"
                  key={key}
                  nftData={nft}
                  price={listing['price']}
                  nftFullData={listing}
                />
              </div>
            )
          })}
        </div>
        {(!error && listingData?.length == 0) && (
          <div className="flex items-center justify-center w-full text-center"><span>No Matching NFTs</span></div>
        )}
        {
          error && (
            <div className="flex items-center justify-center w-full text-center"><span>NFT searching temporarily unavailable. Please try again later.</span>
            </div>
          )
        }
        {
          listingData == null && !error && (
            <div className='flex flex-wrap justify-center overflow-hidden'>
              {

                [...Array(5)].map((item, key) => {
                  return (
                    <div className='px-3' key={key}>
                      <SkeletonLoading />
                    </div>
                  )
                })
              }
            </div>
          )
        }
      </Style>
    )
  }, [pagination, listingData, fBox, filterData, shipSelects, shipListingsMutate, error])

  return <OutPostList />
}

const Style = styled.div`
  .ship-list .scroll-content {
    letter-spacing: initial;
    text-shadow: none;
    display: grid;
    grid-template-columns: repeat(1, 1fr);
    column-gap: 1.25rem;
    width: fit-content;
    margin: auto;

    @media (max-width: 1023px) {
      @media (min-width: 580px) {
        grid-template-columns: repeat(2, 1fr);
      }

      @media (min-width: 850px) {  
        grid-template-columns: repeat(3, 1fr);
      }
    }

    @media (min-width: 1024px) {
      grid-template-columns: repeat(2, 1fr);
    }

    @media (min-width: 1300px) {
      grid-template-columns: repeat(3, 1fr);
    }

    @media (min-width: 1500px) {
      grid-template-columns: repeat(4, 1fr);
    }

    @media (min-width: 1780px) {
      grid-template-columns: repeat(5, 1fr);
    }

    @media (min-width: 2560px) {
      grid-template-columns: repeat(6, 1fr);
    }
  }
`
