"use client"

import React, { useState } from 'react'
import styled from "styled-components"
import { AiFillCaretRight } from "react-icons/ai"
import SideSection from "./SideSection"
import getBreakpoints from "../../services/responsive"

export default function Provider({
  children
}: {
  children: React.ReactNode
}) {
  const breakpoints = getBreakpoints();
  const [sidePanelCollapsed, setSidePanelCollapsed] = useState(true)

  const toggleSidePanel = (): void => setSidePanelCollapsed(!sidePanelCollapsed)

  const onSidePanelWrapperClick = (e: any) => {
    if (!JSON.stringify(e.target['className']).includes('sidePanelHandsetWrapper')) {
      return
    }

    toggleSidePanel()
  }


  return (
    <Style className={`goldman-font flex w-full ${breakpoints.lg ? 'p-8' : 'p-0'}`}>

      <div
        className={`${breakpoints.lg ? 'wrapper' : `handset-wrapper ${sidePanelCollapsed ? 'collapsed' : 'w-full bg-black/75'}`} transition-all`}
        onClick={onSidePanelWrapperClick}
      >
        <SideSection
          onRouteClick={toggleSidePanel}
          onClose={toggleSidePanel}
        />
        {sidePanelCollapsed &&
          <div className="flex justify-center h-full column">
            <div className="flex items-center justify-center nav-tab column"
              onClick={() => setSidePanelCollapsed(false)}>
              <AiFillCaretRight fontSize={10} />
            </div>
          </div>}
      </div>

      <div className={`content-section ${breakpoints.lg ? '' : "handset"} flex-col flex-auto relative`}>
        {children}
      </div>
    </Style>
  )
}

const Style = styled.div`
  .wrapper {
    flex: 0 0 20%;
  }
  
  .handset-wrapper {
    position: absolute;
    height: 100%;
    z-index: 20;
    overflow: hidden;
    
    &.collapsed .sidenav {
      display: none;
    }
    
    .nav-tab {
      margin: auto;
      height: 85px;
      width: 15px;
      left: 0;
      top: 0;
      z-index: 3;
      background: url("/images/ui/nav_tab.svg") no-repeat 100% 100%;
      cursor: pointer;
    }
  }
  
  .content-section {
    background-color: rgba(0, 0, 0, 0.5);
    border: 2px solid #A9E5FFCC;
    border-left: none;
    letter-spacing: 0.15em;
    text-shadow: 0 0 3px rgba(255, 255, 255, 0.7);

    &.handset {
      margin: 0;
      border: none;
      width: 100vw;

      &:before, &:after {
        display: none;
      }
    }
  }
`