import type { Metadata } from 'next'
import Container from '../components/Container'

export const metadata: Metadata = {
  title: 'Dashboard | DEEPSPACE',
  description: 'Sushi',
}


//export const runtime = 'edge' // 'nodejs' (default) | 'edge'

export default function Homepage() {
  return <Container id="dashboard-page" className="py-4 md:py-8 lg:py-12" maxWidth="2xl">
  </Container>
}