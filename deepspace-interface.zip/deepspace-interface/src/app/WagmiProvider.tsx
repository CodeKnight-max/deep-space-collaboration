"use client"
import React from 'react'
import { WagmiConfig, createConfig, configureChains } from 'wagmi'
import { publicProvider } from 'wagmi/providers/public'

import { Config } from '../config/config'
import { SUPPORTED_WALLETS } from '../config/wallets'



const { publicClient, webSocketPublicClient } = configureChains(
  [...Config.chains()],
  [publicProvider()],
  { pollingInterval: 10_000 },
)
const connectors = Object.values(SUPPORTED_WALLETS).map(wallet => wallet.connector)
// Set up wagmi config
const config = createConfig({
  autoConnect: true,
  connectors: connectors,
  publicClient,
  webSocketPublicClient,
})
//const ethereumClient = new EthereumClient(config, chains)
export default function WagmiProvider({ children }: { children: React.ReactNode }) {
  return (
    <>
      <WagmiConfig config={config}>
        {children}
      </WagmiConfig>
    </>
  )
}