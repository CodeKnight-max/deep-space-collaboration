import type { Metadata } from 'next'
import '../styles/index.css'
import { Providers } from '../redux/provider'
import { LanguagePovider } from './LanguagePovider'
import Default from "../layouts/Default"
import WagmiProvider from './WagmiProvider'

export const metadata: Metadata = {
  applicationName: 'DEEPSPACE App',
  themeColor: '#F338C3',
  appleWebApp: {
    title: 'DEEPSPACE App',
    statusBarStyle: 'black-translucent',
  },
  formatDetection: {
    telephone: false,
  },
  icons: {
    icon: [
      { url: '/icons/favicon-32x32.png', sizes: '32x32' },
      { url: '/icons/favicon-96x96.png', sizes: '96x96' }
    ],
    shortcut: ['/icons/favicon.ico'],
    apple: [
      { url: '/icons/apple-touch-icon.png' },
      { url: '/icons/apple-touch-icon.png', sizes: '180x180', type: 'image/png' },
      { url: '/icons/apple-touch-icon-57x57.png', sizes: '57x57', type: 'image/png' },
      { url: '/icons/apple-touch-icon-60x60.png', sizes: '60x60', type: 'image/png' },
      { url: '/icons/apple-touch-icon-72x72.png', sizes: '72x72', type: 'image/png' },
      { url: '/icons/apple-touch-icon-76x76.png', sizes: '76x76', type: 'image/png' },
      { url: '/icons/apple-touch-icon-114x114.png', sizes: '114x114', type: 'image/png' },
      { url: '/icons/apple-touch-icon-120x120.png', sizes: '120x120', type: 'image/png' },
      { url: '/icons/apple-touch-icon-144x144.png', sizes: '144x144', type: 'image/png' },
      { url: '/icons/apple-touch-icon-152x152.png', sizes: '152x152', type: 'image/png' },
      { url: '/icons/apple-touch-icon-180x180.png', sizes: '180x180', type: 'image/png' },
    ],
    other: [
      {
        rel: 'apple-touch-icon-precomposed',
        url: '/apple-touch-icon-precomposed.png',
        sizes: '180x180'
      },
      {
        rel: 'apple-touch-icon-precomposed',
        url: '/apple-touch-icon-57x57-precomposed.png',
        sizes: '57x57'
      },
      {
        rel: 'apple-touch-icon-precomposed',
        url: '/apple-touch-icon-60x60-precomposed.png',
        sizes: '60x60'
      },
      {
        rel: 'apple-touch-icon-precomposed',
        url: '/apple-touch-icon-72x72-precomposed.png',
        sizes: '72x72'
      },
      {
        rel: 'apple-touch-icon-precomposed',
        url: '/apple-touch-icon-76x76-precomposed.png',
        sizes: '76x76'
      },
      {
        rel: 'apple-touch-icon-precomposed',
        url: '/apple-touch-icon-114x114-precomposed.png',
        sizes: '114x114'
      },
      {
        rel: 'apple-touch-icon-precomposed',
        url: '/apple-touch-icon-120x120-precomposed.png',
        sizes: '120x120'
      },
      {
        rel: 'apple-touch-icon-precomposed',
        url: '/apple-touch-icon-144x144-precomposed.png',
        sizes: '144x144'
      },
      {
        rel: 'apple-touch-icon-precomposed',
        url: '/apple-touch-icon-152x152-precomposed.png',
        sizes: '152x152'
      },
      {
        rel: 'apple-touch-icon-precomposed',
        url: '/apple-touch-icon-180x180-precomposed.png',
        sizes: '180x180'
      },
    ],
  },
  manifest: '/site.webmanifest',
  openGraph: {
    type: 'website',
    siteName: 'DEEPSPACE App',
    url: '',
    images: { url: 'https://branding.deepspace.game/DPS_logo_96.png' },
    description: ''
  },
  viewport: {
    width: 'device-width',
    initialScale: 1,
    minimumScale: 1,
    maximumScale: 1,
    userScalable: false,
  },
  // twitter: {
  //   card: 'app',
  //   title: 'DEEPSPACE App',
  //   url: 'https://twitter.com/DeepSpaceBSC',
  //   description: 'DEEPSPACE crypto game & supporting NFT marketplace.',
  // },
}
export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Goldman:wght@400;700&family=Lato:wght@400;700&display=swap"
          rel="stylesheet"
        />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <title key="title">{process.env.NEXT_PUBLIC_PAGE_TITLE}</title>
      </head>
      <body
        style={{
          background: `url("/images/background.webp")`,
          backgroundPosition: 'center center',
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          backgroundAttachment: 'fixed',
          overflow: 'auto'
        }}
      >
        <div id="stars"></div>
        <div id="stars2"></div>
        <div id="stars3"></div>
        <LanguagePovider>
          <WagmiProvider>
            <Providers>
              <Default>
                {children}
              </Default>
            </Providers>
          </WagmiProvider>
        </LanguagePovider>
      </body>
    </html>
  )
}