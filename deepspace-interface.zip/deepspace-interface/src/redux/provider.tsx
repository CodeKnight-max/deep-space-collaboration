"use client"

import store, { persistor } from '../state'
import { Provider } from "react-redux"
import { PersistGate } from 'redux-persist/integration/react'

//import ListsUpdater from '../state/lists/updater'
// import UserUpdater from '../state/user/updater'
// import ApplicationUpdater from '../state/application/updater'
// import TransactionUpdater from '../state/transactions/updater'
import MulticallUpdater from '../state/multicall/updater'

export function Providers({ children }: { children: React.ReactNode }) {
  return <Provider store={store}>
    <PersistGate loading={null} persistor={persistor}>
      <>
        {/* <ListsUpdater /> */}
        {/* <UserUpdater /> */}
        {/* <ApplicationUpdater /> */}
        {/* <TransactionUpdater /> */}
        <MulticallUpdater />
      </>

      {children}
    </PersistGate>
  </Provider>
}
