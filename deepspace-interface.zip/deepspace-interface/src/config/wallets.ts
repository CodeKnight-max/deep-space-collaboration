import { Connector } from '@wagmi/core'
import { InjectedConnector } from 'wagmi/connectors/injected'
import { publicProvider } from 'wagmi/providers/public'
import { configureChains } from 'wagmi'
import { WalletConnectConnector } from 'wagmi/connectors/walletConnect'

//import { NetworkConnector } from '../entities/NetworkConnector'
import RPC from './rpc'
import config from '.'
import { StaticImageData } from 'next/image'
import injectedIcon from '../asset/image/wallets/injected.svg'
import metamaskIcon from '../asset/image/wallets/metamask.png'
import walletConnectIcon from '../asset/image/wallets/wallet-connect.svg'
import bscIcon from '../asset/image/wallets/bsc.jpg'
import { Config } from '../config/config'
import { BinanceWalletConnector } from '../entities/binanceWalletConnector'

/*export const network = new NetworkConnector({
  defaultChainId: config.DEFAULT_CHAIN,
  urls: RPC,
})*/

//const supportedChainIds = Object.values(ChainId) as number[]
const supportedChainIds = [config.DEFAULT_CHAIN]

export const injected = new InjectedConnector({
  chains: Config.chains(),
  options: {
    name: 'Injected',
    shimDisconnect: true,
  },
})

export interface WalletInfo {
  connector?: Connector
  name: string
  icon: StaticImageData
  description: string
  href: string | null
  color: string
  primary?: true
  mobile?: true
  mobileOnly?: true
}

const { chains } = configureChains(Config.chains(), [publicProvider()], {
  pollingInterval: 10_000,
})
const projectId = 'eb8e243732621415799f100d119a1c55'

export const SUPPORTED_WALLETS: { [key: string]: WalletInfo } = {
  /*INJECTED: {
    connector: new InjectedConnector({
      chains,
      options: {
        name: 'Injected',
        shimDisconnect: true,
      },
    }),
    name: 'Injected',
    icon: injectedIcon,
    description: 'Injected web3 provider.',
    href: null,
    color: '#010101',
    primary: true,
  },*/
  METAMASK: {
    connector: new InjectedConnector({
      chains,
      options: {
        name: 'MetaMask',
        shimDisconnect: true,
      },
    }),
    name: 'MetaMask',
    icon: metamaskIcon,
    description: 'Easy-to-use browser extension.',
    href: null,
    color: '#E8831D',
  },
  WALLET_CONNECT: {
    connector: new WalletConnectConnector({
      chains,
      options: {
        projectId,
        showQrModal: true,
      },
    }),
    name: 'WalletConnect',
    icon: walletConnectIcon,
    description: 'Connect to Trust Wallet, Rainbow Wallet and more...',
    href: null,
    color: '#4196FC',
    mobile: true,
  },
  Binance: {
    connector: new BinanceWalletConnector({ chains }),
    name: 'Binance Chain Wallet',
    icon: bscIcon,
    description: 'Login using Binance hosted wallet',
    href: null,
    color: '#F0B90B',
    mobile: true,
  },
}
