import { bsc, bscTestnet } from 'wagmi/chains'
import { ENV_TYPES } from '../constants'
import { ENVIRONMENT } from '../config'

const ENV_CHAINS = {
  [ENV_TYPES.DEVELOPMENT]: [bscTestnet],
  [ENV_TYPES.TEST]: [bscTestnet],
  [ENV_TYPES.PRODUCTION]: [bsc],
}

class Config {
  // public static backendUrl = () => ENV_BACKEND_URI[getEnvironment()];
  // public static assetsBaseUri = () => ENV_ASSETS_BASE_URI[getEnvironment()];
  // public static contractAddressTokenEth = () =>
  //   ENV_CONTRACT_ADDRESS_TOKEN_ETH[getEnvironment()];
  // public static contractAddressTokenBsc = () =>
  //   ENV_CONTRACT_ADDRESS_TOKEN_BSC[getEnvironment()];
  // public static contractAddressBridgeEth = () =>
  //   ENV_CONTRACT_ADDRESS_BRIDGE_ETH[getEnvironment()];
  // public static contractAddressBridgeBsc = () =>
  //   ENV_CONTRACT_ADDRESS_BRIDGE_BSC[getEnvironment()];
  // public static contractAddressResourcesBsc = () =>
  //   ENV_CONTRACT_ADDRESS_RESOURCES_BSC[getEnvironment()];
  // public static chainIdEth = () => ENV_CHAIN_ID_ETH[getEnvironment()];
  // public static chainIdBsc = () => ENV_CHAIN_ID_BSC[getEnvironment()];
  public static chains = () => ENV_CHAINS[ENVIRONMENT]
}

export { Config }
