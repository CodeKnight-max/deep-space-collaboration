import { ChainId } from '@deepspace-game/sdk'
import bscIcon from '../asset/image/wallets/bsc.jpg'

export const NETWORK_ICON = {
  [ChainId.BSC]: bscIcon,
  [ChainId.BSC_TESTNET]: bscIcon,
  [ChainId.GOERLI]: bscIcon,
}

export const NETWORK_LABEL: { [chainId in ChainId]?: string } = {
  [ChainId.BSC]: 'BSC',
  [ChainId.BSC_TESTNET]: 'BSC Testnet',
  [ChainId.GOERLI]: 'Goerli',
}
