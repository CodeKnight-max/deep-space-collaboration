'use client'
import Footer from '../../components/Footer'
import Header from '../../components/Header'
//import Banner from '../../components/Banner'
import React, { RefObject, useEffect, useState } from "react"
import Scrollbar from "smooth-scrollbar"
import StarFlow from "../../components/StarFlow"

const Layout = ({ children }: { children: React.ReactNode }) => {
  const root: RefObject<HTMLDivElement> = React.createRef()
  let scrollbar;

  const [isAtBottom, setIsAtBottom] = useState(false)

  useEffect(() => {
    scrollbar = Scrollbar.init(root.current)
  }, [root])

  const scrollToBottom = () => {
    scrollbar.scrollTo(0, scrollbar.limit.y, 400)
    setIsAtBottom(true)
  }

  const scrollToTop = () => {
    scrollbar.scrollTo(0, 0, 200)
    setIsAtBottom(false)
  }
  return (
    <>
      <div ref={root} className="relative z-10 flex flex-col h-screen">
        <div className='flex flex-col flex-auto h-screen pb-10'>
          <Header />
          {/* {banner && <Banner />} */}
          <main className="relative flex flex-auto overflow-hidden">{children}</main>
          <div id="modal-root"></div>
        </div>

        <div className='footer-wrapper'>
          <Footer isAtBottom={isAtBottom}
            scrollToBottom={scrollToBottom}
            scrollToTop={scrollToTop} />
        </div>
      </div>
      <StarFlow />
    </>
  )
}

export default Layout
