import React, { useEffect, useState } from "react";
import { AiFillCloseCircle } from "react-icons/ai";
import ReactDOM from "react-dom";
import styled from "styled-components";
import Lottie from "react-lottie";
import modal_border from "../../lottie/modal_border.json"
import getBreakpoints from "../../services/responsive";

interface SwapModalProps {
  show: boolean
  onRampDefault: boolean
  onClose: () => void
}

export default function SwapModal(props: SwapModalProps) {
  const breakpoints = getBreakpoints()

  const [isReady, setIsReady] = useState(false);
  const [isBrowser, setIsBrowser] = useState(false);

  useEffect(() => {
    setIsBrowser(true);
  }, [])

  const borderOptions = {
    loop: false,
    autoplay: true,
    animationData: modal_border,
    rendererSettings: {
      preserveAspectRatio: 'none'
    }
  }

  const close = () => {
    setIsReady(false)
    props.onClose()
  }

  const modalContent = props.show ? (
    <StyledCard className="z-50 Modal" onClick={close}>
      <div className='relative flex'>
        <div className="close-button" style={{opacity: isReady ? 100 : 0}}>
          <AiFillCloseCircle onClick={() => close}
                             style={{ cursor: 'pointer', color: 'white', fontSize: "21px" }}/>
        </div>
        <div className="border-wrapper">
          <Lottie options={borderOptions}
                  height={'100%'} width={'100%'}
                  eventListeners={[{eventName: 'complete', callback: () => setIsReady(true)}]}/>
        </div>

        <div className="transition-all px-20 py-10" style={{opacity: isReady ? 100 : 0}}>
          <iframe width="400" height="690" frameBorder="0"
                  allow="clipboard-read *; clipboard-write *; web-share *; accelerometer *; autoplay *; camera *; gyroscope *; payment *; geolocation *"
                  src={`https://flooz.trade/embed/trade?swapDisabled=false&swapToTokenAddress=0xf275e1AC303a4C9D987a2c48b8E555A77FeC3F1C&swapLockToToken=true&onRampDisabled=false&onRampAsDefault=${props.onRampDefault}&onRampDefaultAmount=50&network=bsc&lightMode=false&primaryColor=%23650aae&roundedCorners=0&padding=20&refId=OXiK5M`}></iframe>
        </div>
      </div>
    </StyledCard>
  ) : null
  if (!isBrowser) {
    return null
  } else {
    return ReactDOM.createPortal(modalContent, document.getElementById('modal-root'))
  }
}

const StyledCard = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100vw;
  height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  right: auto;
  bottom: auto;
  margin-right: -50%;
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
  cursor: pointer;
  
  .close-button {
    position: absolute;
    top: 20px;
    right: 35px;
  }

  .border-wrapper {
    position: absolute;
    width: 100%;
    height: 100%;
    z-index: -1;
  }
`
