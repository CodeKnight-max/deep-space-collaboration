import Link from 'next/link'
import React from 'react'

import { usePathname } from 'next/navigation'

const NavLink = ({ children, exact = false, activeClassName = 'text-high-emphesis', ...props }) => {
  const asPath = usePathname()
  const childClassName = props.className || ''

  // pages/index.js will be matched via props.href
  // pages/about.js will be matched via props.href
  // pages/[slug].js will be matched via props.as

  const isActive = exact
    ? (props.as || props.href) === asPath
    : asPath.startsWith(props.as || props.href)

  const className = isActive ? `${childClassName} ${activeClassName}`.trim() : childClassName
  const updatePros = { ...props, className }
  return (
    <Link href={props.href} {...updatePros}>
      {children}
    </Link>
  )
}

export default NavLink
