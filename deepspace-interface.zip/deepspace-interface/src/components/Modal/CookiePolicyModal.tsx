import React, { useEffect, useState } from "react";
import { AiFillCloseCircle } from "react-icons/ai";
import { StakingHeader } from "../StakingHeader";
import ReactDOM from "react-dom";
import styled from "styled-components";

const StyledCard = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100vw;
  height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  right: auto;
  bottom: auto;
  margin-right: -50%;
  backdrop-filter:blur(12px);
  -webkit-backdrop-filter:blur(12px);
  
  .body {
    justify-content: center;
    width: auto;
    color:white;
    overflow:auto;
    max-width:960px;
    background-color:#202231;
  }
  h1, h2 {
    font-weight: bold;
  }
  h1 {
    font-size: 1.25rem;
    line-height: 1.75rem;
    margin-bottom: 20px;
  }
  h2 {
    font-size: 1.125rem;
    line-height: 1.75rem;
    margin-bottom: 15px;
  }
  p {
    margin-bottom: 10px;
  }
  ul {
    list-style: initial;
    margin: 10px;
    padding: 10px;
  }
  a {
    color: #ccc;
    font-weight: bold;
  }
  .helper-table table{
      width:48%;
      font-size:14px;
  }
  .helper-content{
      max-height:calc( 100vh - 250px );
      overflow:auto;
  }
  .helper-content::-webkit-scrollbar {
    width: 9px;
    }
    .helper-content::-webkit-scrollbar-track {
        background-color:transparent;
        border-radius:6px;
        border:1px solid gray;
        overflow:hidden;
    }
    .helper-content::-webkit-scrollbar-thumb {
        background-color:#0A1014;
        border-radius:6px;
        box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
    }
  .helper-table table,tr,td,th{
    border:1px solid gray;
    border-collapse:collapse;
    padding:6px 12px;
  }
  .warning-message{
      font-size:14px;
  }
  @media(max-width:576px){
    .helper-table table{
        width:100%;
        font-size:12px;
    }
    .helper-content{
        font-size:13px;
    }
  }
  @media(max-width:500px){
    .staking-table table{
        min-width:initial;
    }
  }

`

export default function CookiePolicyModal({ show, onClose }) {
  const [isBrowser, setIsBrowser] = useState(false);
  useEffect(() => {
    setIsBrowser(true);
  }, [])
  const modalContent = show ? (
    <StyledCard className="z-50 Modal">
      <div>

        <div className='relative flex p-3 mx-3 body w-90 py-7 sm:p-7 sm:py-10'>
          <div>
            <div className="absolute top-3 right-3 close-button">
              <AiFillCloseCircle onClick={(e) => {
                onClose()
              }} style={{ cursor: 'pointer', color: 'white', fontSize: "21px" }}/>
            </div>
            <StakingHeader className={'text-sm font-bold md:text-2xl text-center'}
                           content={'Cookie Policy'}/>
            <hr className='mx-3 mt-3 mb-3' style={{ borderColor: 'gray' }}/>
            <div className="helper-content">
              <div className='mx-3'>
                <h1>Cookie Policy</h1>
                <p>Last updated: September 29, 2022</p>
                <p>This Cookies Policy explains what Cookies are and how We use them. You should read this policy so You can understand what type of cookies We use, or the information We collect using Cookies and how that information is used.</p>
                <p>Cookies do not typically contain any information that personally identifies a user, but personal information that we store about You may be linked to the information stored in and obtained from Cookies. For further information on how We use, store and keep your personal data secure, see our Privacy Policy.</p>
                <p>We do not store sensitive personal information, such as mailing addresses, account passwords, etc. in the Cookies We use.</p>
                <h1>Interpretation and Definitions</h1>
                <h2>Interpretation</h2>
                <p>The words of which the initial letter is capitalized have meanings defined under the following conditions. The following definitions shall have the same meaning regardless of whether they appear in singular or in plural.</p>
                <h2>Definitions</h2>
                <p>For the purposes of this Cookies Policy:</p>
                <ul>
                  <li><strong>Company</strong> (referred to as either &quot;the Company&quot;, &quot;We&quot;, &quot;Us&quot; or &quot;Our&quot; in this Cookies Policy) refers to Chainify LLC, 30 North Gould Street Suite R Sheridan, WY 82801.</li>
                  <li><strong>Cookies</strong> means small files that are placed on Your computer, mobile device or any other device by a website, containing details of your browsing history on that website among its many uses.</li>
                  <li><strong>Website</strong> refers to DEEPSPACE, accessible from <a href="https://deepspace.game/" rel="external nofollow noreferrer" target="_blank">https://deepspace.game/</a></li>
                  <li><strong>You</strong> means the individual accessing or using the Website, or a company, or any legal entity on behalf of which such individual is accessing or using the Website, as applicable.</li>
                </ul>
                <h1>The use of the Cookies</h1>
                <h2>Type of Cookies We Use</h2>
                <p>Cookies can be &quot;Persistent&quot; or &quot;Session&quot; Cookies. Persistent Cookies remain on your personal computer or mobile device when You go offline, while Session Cookies are deleted as soon as You close your web browser.</p>
                <p>We use both session and persistent Cookies for the purposes set out below:</p>
                <ul>
                  <li>
                    <p><strong>Necessary / Essential Cookies</strong></p>
                    <p>Type: Session Cookies</p>
                    <p>Administered by: Us</p>
                    <p>Purpose: These Cookies are essential to provide You with services available through the Website and to enable You to use some of its features. They help to authenticate users and prevent fraudulent use of user accounts. Without these Cookies, the services that You have asked for cannot be provided, and We only use these Cookies to provide You with those services.</p>
                  </li>
                  <li>
                    <p><strong>Cookies Policy / Notice Acceptance Cookies</strong></p>
                    <p>Type: Persistent Cookies</p>
                    <p>Administered by: Us</p>
                    <p>Purpose: These Cookies identify if users have accepted the use of cookies on the Website.</p>
                  </li>
                  <li>
                    <p><strong>Functionality Cookies</strong></p>
                    <p>Type: Persistent Cookies</p>
                    <p>Administered by: Us</p>
                    <p>Purpose: These Cookies allow us to remember choices You make when You use the Website, such as remembering your login details or language preference. The purpose of these Cookies is to provide You with a more personal experience and to avoid You having to re-enter your preferences every time You use the Website.</p>
                  </li>
                  <li>
                    <p><strong>Tracking and Performance Cookies</strong></p>
                    <p>Type: Persistent Cookies</p>
                    <p>Administered by: Third-Parties</p>
                    <p>Purpose: These Cookies are used to track information about traffic to the Website and how users use the Website. The information gathered via these Cookies may directly or indirectly identify you as an individual visitor. This is because the information collected is typically linked to a pseudonymous identifier associated with the device you use to access the Website. We may also use these Cookies to test new advertisements, pages, features or new functionality of the Website to see how our users react to them.</p>
                  </li>
                  <li>
                    <p><strong>Targeting and Advertising Cookies</strong></p>
                    <p>Type: Persistent Cookies</p>
                    <p>Administered by: Third-Parties</p>
                    <p>Purpose: These Cookies track your browsing habits to enable Us to show advertising which is more likely to be of interest to You. These Cookies use information about your browsing history to group You with other users who have similar interests. Based on that information, and with Our permission, third party advertisers can place Cookies to enable them to show adverts which We think will be relevant to your interests while You are on third party websites.</p>
                  </li>
                </ul>
                <h2>Your Choices Regarding Cookies</h2>
                <p>If You prefer to avoid the use of Cookies on the Website, first You must disable the use of Cookies in your browser and then delete the Cookies saved in your browser associated with this website. You may use this option for preventing the use of Cookies at any time.</p>
                <p>If You do not accept Our Cookies, You may experience some inconvenience in your use of the Website and some features may not function properly.</p>
                <p>If You'd like to delete Cookies or instruct your web browser to delete or refuse Cookies, please visit the help pages of your web browser.</p>
                <ul>
                  <li>
                    <p>For the Chrome web browser, please visit this page from Google: <a href="https://support.google.com/accounts/answer/32050" rel="external nofollow noreferrer" target="_blank">https://support.google.com/accounts/answer/32050</a></p>
                  </li>
                  <li>
                    <p>For the Internet Explorer web browser, please visit this page from Microsoft: <a href="http://support.microsoft.com/kb/278835" rel="external nofollow noreferrer" target="_blank">http://support.microsoft.com/kb/278835</a></p>
                  </li>
                  <li>
                    <p>For the Firefox web browser, please visit this page from Mozilla: <a href="https://support.mozilla.org/en-US/kb/delete-cookies-remove-info-websites-stored" rel="external nofollow noreferrer" target="_blank">https://support.mozilla.org/en-US/kb/delete-cookies-remove-info-websites-stored</a></p>
                  </li>
                  <li>
                    <p>For the Safari web browser, please visit this page from Apple: <a href="https://support.apple.com/guide/safari/manage-cookies-and-website-data-sfri11471/mac" rel="external nofollow noreferrer" target="_blank">https://support.apple.com/guide/safari/manage-cookies-and-website-data-sfri11471/mac</a></p>
                  </li>
                </ul>
                <p>For any other web browser, please visit your web browser's official web pages.</p>
                <h2>More Information about Cookies</h2>
                <p>You can learn more about cookies: <a href="https://www.freeprivacypolicy.com/blog/cookies/" rel="noreferrer" target="_blank">Cookies: What Do They Do?</a>.</p>
                <h2>Contact Us</h2>
                <p>If you have any questions about this Cookies Policy, You can contact us:</p>
                <ul>
                  <li>By email: <a href="mailto:privacy@deepspace.game">privacy@deepspace.game</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>

        </div>
      </div>
    </StyledCard>
  ) : null
  if (!isBrowser) {
    return null
  } else {
    return ReactDOM.createPortal(modalContent, document.getElementById('modal-root'))
  }
}