import React from "react";
import styled from "styled-components";
import { AiOutlineRight } from "react-icons/ai"

interface PanelProps {
  title: string
  active?: boolean
  children?: React.ReactChild | React.ReactChild[]
  onHeaderClick?: () => void
}

export default function Panel(props: PanelProps): JSX.Element {
  return (
    <Style className={props.active ? 'active' : ''}>
      <div className="panel-header" onClick={props.onHeaderClick}>
        <span className="title">{props.title}</span>

        <div className="flex items-center">
          <AiOutlineRight className="panel-toggle" fontSize={22}/>
        </div>
      </div>

      <div className="panel-body">
        { props.children }
      </div>
    </Style>
  )
}

const Style = styled.div`
  background: url("/images/ui/list_item.svg") no-repeat 100% 100%;
  margin-bottom: 1rem;

  &.active .panel-header, .panel-header:hover {
    background: url("/images/ui/panel_active_header.svg") no-repeat 100% 100%;
  }

  &.active {
    .panel-toggle {
      color: #00aeef;
      transform: rotate(90deg);
    }

    .panel-body {
      height: fit-content;
    }
  }

  .panel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 35px;
    background: none;
    padding: 0 1rem;
    transition: all 150ms;

    &:hover {
      cursor: pointer;
    }
  }

  .panel-toggle {
    transform: rotate(0);
    transition: all 150ms;
  }

  .panel-body {
    height: 0;
    overflow: hidden;
    transition: height 150ms;
    margin: 0 0.3rem;

    .property {
      margin: 0 0.6rem;

      &:nth-of-type(odd) {
        background: url("/images/ui/bg_odd.svg") no-repeat 100% 100%;
      }

      &:nth-of-type(even) {
        background: url("/images/ui/bg_even.svg") no-repeat 100% 100%;
      }
    }
  }
`