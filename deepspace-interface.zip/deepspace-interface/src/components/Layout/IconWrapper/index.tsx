import styled from "styled-components";
import React from "react";
import Image from "next/image";

interface IconWrapperProps {
  icon: string
  className: string
  size?: number
  width?: number
  height?: number
}

export default function IconWrapper(props: IconWrapperProps): JSX.Element {
  return (
    <Style className={`flex items-center justify-center ${props.className}`}>
      <Image src={props.icon} width={props.size ?? props.width}
        height={props.size ?? props.height}
        alt='IconWrapper'
      />
    </Style>
  )
}

const Style = styled.div`
  background-image: url("/images/ui/icon_box.svg");
  background-repeat: no-repeat;
  background-size: 100% 100%;
`
