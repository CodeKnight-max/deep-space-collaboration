import { useState, useEffect } from 'react'
import { useAccount, useNetwork } from 'wagmi'
import { getWalletClient } from '@wagmi/core'
import { createWalletClient, custom } from 'viem'
import { Config } from '../config/config'

declare global {
  interface Window {
    ethereum?: {
      isMetaMask?: true
      on?: (...args: any[]) => void
      removeListener?: (...args: any[]) => void
      autoRefreshOnNetworkChange?: boolean
    }
  }
}
export function useActiveWeb3React() {
  const [walletClient, setWalletClient] = useState<any>()
  const { address, isConnecting, connector, isDisconnected } = useAccount()
  const { chain } = useNetwork()
  const [chainId, setChainId] = useState(chain?.id)
  const [signer, setSigner] = useState<any>()
  useEffect(() => {
    if (window.ethereum !== undefined) {
      let client
      if (chain) {
        // @ts-ignore
        client = createWalletClient({ chain, transport: custom(window.ethereum) })
        setWalletClient(client)
      }

      if (chain?.id === undefined) {
        if (Config.chains()[0]?.id) setChainId(Config.chains()[0]?.id)
      }
      getWalletClient().then((_walletClient) => setSigner(_walletClient))
    }
  }, [chain?.id])
  return {
    account: address,
    chainId: chain?.id ?? chainId,
    connector,
    isConnecting,
    isDisconnected,
    walletClient,
    signer,
  }
}

export default useActiveWeb3React
