module.exports = {
  presets: ['next/babel'],
  plugins: ['@babel/plugin-proposal-private-methods', 'macros', ['styled-components', { ssr: true }]],
}
